# Mod Menu Template  

![Mod Menu Banner](https://media.discordapp.net/attachments/1346469712510451722/1348806731525787719/image.png?ex=67dff6e8&is=67dea568&hm=8357da6342a135eb612f372f1193bdc866bf81c0cfe4e37c943a9811aa5fe04b&=&format=webp&quality=lossless&width=765&height=856)  

## 🚀 About  
It’s inspired by **symex**, and I hope you enjoy it.  

## 💡 Suggestions  
If you’d like me to create more templates, let me know!  
Join our **Discord server** and drop your suggestions:  
👉 [Join Here](https://discord.gg/KXABTbrQx2)  

## 📜 Disclaimer  
This is for **educational purposes only**. I am not responsible for how this is used.  

This is also my first ever template i made about a few months ago

## ❤️ Credits  
Credits to **iidk** for the main template it made it easier to create menus with it.  
*(Also please make me an actual mod creator in your server)*  

**https://discord.gg/KXABTbrQx2**
