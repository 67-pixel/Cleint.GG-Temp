﻿using GorillaLocomotion;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.InputSystem;
using Object = UnityEngine.Object;

namespace TWOTIMEPAID.Mods
{
    class RigMods
    {
    }
}

class Arms
{
    public static void FixHead()
    {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0f;
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0f;
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0f;
    }


    public static void UpsideDownHead()
    {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 180f;
    }


    public static void BrokenNeck()
    {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 90f;
    }


    public static void BackwardsHead()
    {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 180f;
    }

    public static void AutoTPose()
    {
        bool flag = ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.leftButton.isPressed;
        if (flag)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f);
            try
            {
                GorillaTagger.Instance.myVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f);
            }
            catch
            {
            }
            GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
            try
            {
                GorillaTagger.Instance.myVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
            }
            catch
            {
            }
            GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * -1f;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }
    public static void HelicopterMod()
    {
        bool flag = ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.leftButton.isPressed;
        if (flag)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position += new Vector3(0f, 0.05f, 0f);
            try
            {
                GorillaTagger.Instance.myVRRig.transform.position += new Vector3(0f, 0.05f, 0f);
            }
            catch
            {
            }
            GorillaTagger.Instance.offlineVRRig.transform.rotation = Quaternion.Euler(GorillaTagger.Instance.offlineVRRig.transform.rotation.eulerAngles + new Vector3(0f, 10f, 0f));
            try
            {
                GorillaTagger.Instance.myVRRig.transform.rotation = Quaternion.Euler(GorillaTagger.Instance.offlineVRRig.transform.rotation.eulerAngles + new Vector3(0f, 10f, 0f));
            }
            catch
            {
            }
            GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * -1f;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.right * 1f;
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }


}


public static class Visuals
{
    private static bool isInvisible = false;
    private static bool lastButtonState = false;

    public static void Invis()
    {

        bool buttonPressed = ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.leftButton.isPressed;

        if (buttonPressed && !lastButtonState)
        {
            isInvisible = !isInvisible;

            if (isInvisible)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(99999f, 99999f, 99999f);
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
                GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.zero;
            }
        }


        if (isInvisible)
        {
            GTPlayer instance = GTPlayer.Instance;

            // Left Sphere
            GameObject leftObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            leftObj.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            leftObj.transform.parent = instance.leftControllerTransform;
            leftObj.transform.rotation = instance.leftControllerTransform.rotation;
            leftObj.transform.position = instance.leftControllerTransform.position;
            Renderer leftRend = leftObj.GetComponent<Renderer>();
            leftRend.material.shader = Shader.Find("GorillaTag/UberShader");
            leftRend.material.color = Color.gray1;
            Object.Destroy(leftObj.GetComponent<Collider>());
            Object.Destroy(leftObj, Time.deltaTime);

            // Right Sphere
            GameObject rightObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            rightObj.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            rightObj.transform.parent = instance.rightControllerTransform;
            rightObj.transform.rotation = instance.rightControllerTransform.rotation;
            rightObj.transform.position = instance.rightControllerTransform.position;
            Renderer rightRend = rightObj.GetComponent<Renderer>();
            rightRend.material.shader = Shader.Find("GorillaTag/UberShader");
            rightRend.material.color = Color.gray1;
            Object.Destroy(rightObj.GetComponent<Collider>());
            Object.Destroy(rightObj, Time.deltaTime);
        }


        lastButtonState = buttonPressed;
    }
}








class Ghost_Monke
{
    public static bool ghostToggle = false;

    public static void GhostMonkeMod()
    {

        if (ControllerInputPoller.instance.rightControllerSecondaryButton || Mouse.current.leftButton.isPressed)
        {
            ghostToggle = !ghostToggle;
        }


        if (ghostToggle)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;

            GTPlayer instance = GTPlayer.Instance;

            GameObject leftObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            leftObj.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            leftObj.transform.parent = instance.leftControllerTransform;
            leftObj.transform.rotation = instance.leftControllerTransform.rotation;
            leftObj.transform.position = instance.leftControllerTransform.position;
            Renderer leftRend = leftObj.GetComponent<Renderer>();
            leftRend.material.shader = Shader.Find("GorillaTag/UberShader");
            leftRend.material.color = Color.softRed;
            Object.Destroy(leftObj.GetComponent<Collider>());
            Object.Destroy(leftObj, Time.deltaTime);

            GameObject rightObj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            rightObj.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            rightObj.transform.parent = instance.rightControllerTransform;
            rightObj.transform.rotation = instance.rightControllerTransform.rotation;
            rightObj.transform.position = instance.rightControllerTransform.position;
            Renderer rightRend = rightObj.GetComponent<Renderer>();
            rightRend.material.shader = Shader.Find("GorillaTag/UberShader");
            rightRend.material.color = Color.softRed;
            Object.Destroy(rightObj.GetComponent<Collider>());
            Object.Destroy(rightObj, Time.deltaTime);
        }
        else // Toggle OFF - Restore rig
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }
}







