﻿using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace TwoTimeDarkUnititledTempmadebyme.Mods
{
    class Seetingsb
    {
        private static Vector3 oldMousePos;
        public static int colorIndex = 0;
        public static Color32 color = new Color(0.8f, 0.07f, 0.2f); // Start

        public static void ChangeColor()
        {
            colorIndex++;
            if (colorIndex == 12)
            {
                colorIndex = 0;
                color = Color.darkRed;
                Main.GetIndex("cc").overlapText = "Change Color: Background";
            }
            if (colorIndex == 0)
            {
                color = Color.darkRed;
                Main.GetIndex("cc").overlapText = "Change Color: Background";
            }
            if (colorIndex == 1)
            {
                color = Color.softRed;
                Main.GetIndex("cc").overlapText = "Change Color: Buttons";
            }
            if (colorIndex == 2)
            {
                color = new Color(1f, 0f, 0f);
                Main.GetIndex("cc").overlapText = "Change Color: Red";
            }
            if (colorIndex == 3)
            {
                color = new Color(0f, 1f, 0f);
                Main.GetIndex("cc").overlapText = "Change Color: Green";
            }
            if (colorIndex == 4)
            {
                color = new Color(0f, 0f, 1f);
                Main.GetIndex("cc").overlapText = "Change Color: Blue";
            }
            if (colorIndex == 5)
            {
                color = new Color(1f, 0f, 1f);
                Main.GetIndex("cc").overlapText = "Change Color: Magenta";
            }
            if (colorIndex == 6)
            {
                color = new Color(1f, 1f, 0f);
                Main.GetIndex("cc").overlapText = "Change Color: Yellow";
            }
            if (colorIndex == 7)
            {
                color = new Color(0f, 1f, 1f);
                Main.GetIndex("cc").overlapText = "Change Color: Cyan";
            }
            if (colorIndex == 8)
            {
                color = new Color(0f, 0f, 0f);
                Main.GetIndex("cc").overlapText = "Change Color: Black";
            }
            if (colorIndex == 9)
            {
                color = new Color(1f, 1f, 1f);
                Main.GetIndex("cc").overlapText = "Change Color: White";
            }
            if (colorIndex == 10)
            {
                color = new Color32(89, 46, 131, 255);
                Main.GetIndex("cc").overlapText = "Change Color: Cool Purple";
            }
            if (colorIndex == 11)
            {
                color = new Color32(145, 0, 255, 255);
                Main.GetIndex("cc").overlapText = "Change Color: Purple";
            }
        }
        public static void SetColor()
        {
            Main.ColorLib2(color);
        }

        public static Color32 savedColor;

        public static void SaveColor()
        {
            savedColor = new Color32((byte)PlayerPrefs.GetFloat("redValue"), (byte)PlayerPrefs.GetFloat("greenValue"), (byte)PlayerPrefs.GetFloat("blueValue"), 255);
        }

        public static void LoadColor()
        {
            Main.ColorLib2(savedColor);
            NotifiLib.SendNotification("[<color=red>TT</color>]: Loaded saved color.");
        }
    }
}
