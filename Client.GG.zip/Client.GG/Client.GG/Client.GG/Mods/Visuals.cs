﻿using GorillaLocomotion;
using GorillaNetworking;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;
using UnityEngine;
using TWOTIMEPAID.Mods;
using TMPro;
using HarmonyLib;
using StupidTemplate.Menu;
using PlayFab.ClientModels;
using PlayFab;
using Object = UnityEngine.Object;

namespace TWOTIMEPAID.Mods
{
    class Visuals
    {
    }
}

class ChamsMods
{
    public static void ChamsMod()
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            bool flag = vrrig.mainSkin.material.name.Contains("fected");
            if (flag)
            {
                vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                vrrig.mainSkin.material.color = new Color32(byte.MaxValue, 0, 0, byte.MaxValue);
                GorillaTagger.Instance.offlineVRRig.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
                GorillaTagger.Instance.offlineVRRig.mainSkin.material.color = GorillaTagger.Instance.offlineVRRig.playerColor;
            }
            else
            {
                vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
                vrrig.mainSkin.material.color = new Color32(0, byte.MaxValue, 0, byte.MaxValue);
                GorillaTagger.Instance.offlineVRRig.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
                GorillaTagger.Instance.offlineVRRig.mainSkin.material.color = GorillaTagger.Instance.offlineVRRig.playerColor;
            }
        }
    }
    public static void ChamsOffMOD()
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            bool flag = !vrrig.isOfflineVRRig || !vrrig.isMyPlayer;
            if (flag)
            {
                vrrig.mainSkin.material.shader = Shader.Find("GorillaTag/UberShader");
                vrrig.mainSkin.material.color = vrrig.playerColor;
            }
        }
    }

}







class Bombs
{
    public static GameObject BombObject = null;
    public static Color buttonDefaultA = Color.darkRed;
    public static void BombMod()
    {
        bool flag = ControllerInputPoller.instance.rightGrab || Mouse.current.leftButton.isPressed;
        if (flag)
        {
            bool flag2 = Bombs.BombObject == null;
            if (flag2)
            {
                Bombs.BombObject = GameObject.CreatePrimitive(0);
                UnityEngine.Object.Destroy(Bombs.BombObject.GetComponent<Rigidbody>());
                UnityEngine.Object.Destroy(Bombs.BombObject.GetComponent<SphereCollider>());
                Bombs.BombObject.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
            }
            Bombs.BombObject.transform.position = GorillaTagger.Instance.rightHandTransform.position;
        }
        bool flag3 = Bombs.BombObject != null;
        if (flag3)
        {
            bool flag4 = ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.rightButton.isPressed;
            if (flag4)
            {
                Vector3 vector = GorillaTagger.Instance.bodyCollider.transform.position - Bombs.BombObject.transform.position;
                vector.Normalize();
                GTPlayer.Instance.GetComponent<Rigidbody>().velocity += 25f * vector;
                UnityEngine.Object.Destroy(Bombs.BombObject);
                Bombs.BombObject = null;
            }
            else
            {
                Bombs.BombObject.GetComponent<Renderer>().material.color = Bombs.buttonDefaultA;
            }
        }
    }

}

class bombDisbaler
{
    public static void DisableBomb()
    {
        bool flag = Bombs.BombObject != null;
        if (flag)
        {
            UnityEngine.Object.Destroy(Bombs.BombObject);
            Bombs.BombObject = null;
        }
    }

}


class LavaYou
{
    public static void EnableILavaYou()
    {
        GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_ForestArt_Prefab/").SetActive(true);
        GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_PrefabV/").SetActive(true);
    }
    public static void DisableILavaYou()
    {
        GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_ForestArt_Prefab/").SetActive(false);
        GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_PrefabV/").SetActive(false);
    }

}

class BecomeGhosts
{
    public static void BecomeDAISY09()
    {
        ChangeNameColor.ChangeName("DAISY09");
        ChangeNameColor.ChangeColor(new Color32(byte.MaxValue, 81, 231, byte.MaxValue));
    }
    public static void BecomeECHO()
    {
        ChangeNameColor.ChangeName("ECHO");
        ChangeNameColor.ChangeColor(new Color32(0, 150, byte.MaxValue, byte.MaxValue));
    }
    public static void BecomeHiddenOnLeaderboard()
    {
        ChangeNameColor.ChangeName("________");
        ChangeNameColor.ChangeColor(new Color32(0, 53, 2, byte.MaxValue));
    }
    public static void BecomeJ3VU()
    {
        ChangeNameColor.ChangeName("J3VU");
        ChangeNameColor.ChangeColor(Color.green);
    }
    public static void BecomePBBV()
    {
        ChangeNameColor.ChangeName("PBBV");
        ChangeNameColor.ChangeColor(new Color32(230, 127, 102, byte.MaxValue));
    }

}

class raining
{
    public static void Rain()
    {
        for (int i = 1; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
        {
            BetterDayNightManager.instance.weatherCycle[i] = (BetterDayNightManager.WeatherType)1;
        }
    }

}

class Noraining
{
    public static void NoRain()
    {
        for (int i = 1; i < BetterDayNightManager.instance.weatherCycle.Length; i++)
        {
            BetterDayNightManager.instance.weatherCycle[i] = 0;
        }
    }

}

class TimeMods
{
    public static int TimeOfDayInteger = 0;
    public static void ChangeTime()
    {
        TimeOfDayInteger++;

        if (TimeOfDayInteger == 0)
        {
            Main.GetIndex("change time").overlapText = "Change Time: Untouched";
        }
        if (TimeOfDayInteger == 1)
        {
            Main.GetIndex("change time").overlapText = "Change Time: Morning";
            BetterDayNightManager.instance.SetTimeOfDay(1);
        }
        if (TimeOfDayInteger == 2)
        {
            Main.GetIndex("change time").overlapText = "Change Time: Day";
            BetterDayNightManager.instance.SetTimeOfDay(3);
        }
        if (TimeOfDayInteger == 3)
        {
            Main.GetIndex("change time").overlapText = "Change Time: Evening";
            BetterDayNightManager.instance.SetTimeOfDay(7);
        }
        if (TimeOfDayInteger == 4)
        {
            Main.GetIndex("change time").overlapText = "Change Time: Night";
            BetterDayNightManager.instance.SetTimeOfDay(0);
        }
        if (TimeOfDayInteger == 5)
        {
            TimeOfDayInteger = 0;
            Main.GetIndex("change time").overlapText = "Change Time: Untouched";
        }
    }

}


class ESP
{
    public static void DisplayPlayerESP()
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            if (vrrig != GorillaTagger.Instance.offlineVRRig)
            {
                UnityEngine.Color thecolor = vrrig.playerColor;
                GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                sphere.transform.position = vrrig.transform.position;
                UnityEngine.Object.Destroy(sphere.GetComponent<SphereCollider>());
                sphere.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
                sphere.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                sphere.GetComponent<Renderer>().material.color = thecolor;
                UnityEngine.Object.Destroy(sphere, 0.1f);
            }
        }
    }
    public static void CreatetionDate(GetAccountInfoResult result)
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
            if (flag)
            {
                Transform transform = vrrig.transform.Find("Name Mod");
                GameObject gameObject = ((transform != null) ? transform.gameObject : null);
                bool flag2 = gameObject == null;
                if (flag2)
                {
                    gameObject = new GameObject("Name Mod");
                }
                TextMeshPro textMeshPro = gameObject.AddComponent<TextMeshPro>();
                textMeshPro.richText = true;
                string text = result.AccountInfo.Created.ToString("MMMM dd, yyyy h:mm tt");
                textMeshPro.fontSize = 2f;
                textMeshPro.alignment = (TextAlignmentOptions)514;
                textMeshPro.color = Color.white;
                gameObject.transform.SetParent(vrrig.transform);
                global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
                Transform transform2 = gameObject.transform;
                transform2.position = vrrig.headConstraint.position + new Vector3(0f, 0.7f, 0f);
                transform2.LookAt(Camera.main.transform.position);
                transform2.Rotate(0f, 180f, 0f);
                gameObject.GetComponent<TextMeshPro>().renderer.material.shader = Shader.Find("GUI/Text Shader");
                gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
            }
        }
    }
    public static void NameTagESP()
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
            if (flag)
            {
                Transform transform = vrrig.transform.Find("Name Mod");
                GameObject gameObject = ((transform != null) ? transform.gameObject : null);
                bool flag2 = gameObject == null;
                if (flag2)
                {
                    gameObject = new GameObject("Name Mod");
                }
                TextMeshPro textMeshPro = gameObject.AddComponent<TextMeshPro>();
                textMeshPro.richText = true;
                textMeshPro.text = "\nDistance: " + Vector3.Distance(GorillaTagger.Instance.headCollider.transform.position, vrrig.headConstraint.position).ToString("F1") + "m\nFPS: " + GetFpsOfPlayer(vrrig).ToString();
                textMeshPro.fontSize = 2f;
                textMeshPro.alignment = (TextAlignmentOptions)514;
                textMeshPro.color = Color.white;
                gameObject.transform.SetParent(vrrig.transform);
                global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
                Transform transform2 = gameObject.transform;
                transform2.position = vrrig.headConstraint.position + new Vector3(0f, 0.7f, 0f);
                transform2.LookAt(Camera.main.transform.position);
                transform2.Rotate(0f, 180f, 0f);
                gameObject.GetComponent<TextMeshPro>().renderer.material.shader = Shader.Find("GUI/Text Shader");
                gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
            }
        }
    }
    public static int GetFpsOfPlayer(VRRig v)
    {
        return Traverse.Create(v).Field("fps").GetValue<int>();
    }
    public static void BoxESP()
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            bool flag = vrrig != null && !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
            bool flag2 = flag;
            if (flag2)
            {
                GameObject gameObject = new GameObject("box");
                gameObject.transform.position = vrrig.transform.position;
                GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject gameObject4 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                GameObject gameObject5 = GameObject.CreatePrimitive(PrimitiveType.Cube);
                global::UnityEngine.Object.Destroy(gameObject2.GetComponent<BoxCollider>());
                global::UnityEngine.Object.Destroy(gameObject5.GetComponent<BoxCollider>());
                global::UnityEngine.Object.Destroy(gameObject4.GetComponent<BoxCollider>());
                global::UnityEngine.Object.Destroy(gameObject3.GetComponent<BoxCollider>());
                gameObject2.transform.SetParent(gameObject.transform);
                gameObject2.transform.localPosition = new Vector3(0f, 0.49f, 0f);
                gameObject2.transform.localScale = new Vector3(1f, 0.02f, 0.02f);
                gameObject5.transform.SetParent(gameObject.transform);
                gameObject5.transform.localPosition = new Vector3(0f, -0.49f, 0f);
                gameObject5.transform.localScale = new Vector3(1f, 0.02f, 0.02f);
                gameObject4.transform.SetParent(gameObject.transform);
                gameObject4.transform.localPosition = new Vector3(-0.49f, 0f, 0f);
                gameObject4.transform.localScale = new Vector3(0.02f, 1f, 0.02f);
                gameObject3.transform.SetParent(gameObject.transform);
                gameObject3.transform.localPosition = new Vector3(0.49f, 0f, 0f);
                gameObject3.transform.localScale = new Vector3(0.02f, 1f, 0.02f);
                Color[] array = new Color[]
                {
                        Color.softBlue,
                        Color.softGreen,
                        Color.softRed
                };
                Color color = Color.Lerp(array[(int)(Time.time % 3f / 3f * (float)(array.Length - 1))], array[((int)(Time.time % 3f / 3f * (float)(array.Length - 1)) + 1) % array.Length], Time.time % 3f / 3f * (float)(array.Length - 1) % 1f);
                gameObject2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject5.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject4.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject3.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
                gameObject2.GetComponent<Renderer>().material.color = color;
                gameObject5.GetComponent<Renderer>().material.color = color;
                gameObject4.GetComponent<Renderer>().material.color = color;
                gameObject3.GetComponent<Renderer>().material.color = color;
                gameObject.transform.LookAt(gameObject.transform.position + Camera.main.transform.rotation * Vector3.forward, Camera.main.transform.rotation * Vector3.up);
                global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
            }
        }
    }
}

class FakeUnban
{


    public static void FakeUnbanSelf()
    {
        // Clear UI error messages
        PhotonNetworkController.Instance.UpdateTriggerScreens();
        GorillaScoreboardTotalUpdater.instance.ClearOfflineFailureText();
        GorillaComputer.instance.screenText.DisableFailedState();
        GorillaComputer.instance.functionSelectText.DisableFailedState();
    }
}

class Saturn
{
    public static void SaturnESP()
    {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            if (vrrig != null && !vrrig.isOfflineVRRig && !vrrig.isMyPlayer)
            {
                GameObject gameObject = new GameObject("saturn");
                gameObject.transform.position = vrrig.transform.position;
                gameObject.transform.rotation = vrrig.transform.rotation;

                int segments = 24;
                float planetRadius = 0.5f;
                float ringInnerRadius = 0.6f;
                float ringOuterRadius = 0.9f;
                float ringTilt = 30f * Mathf.Deg2Rad;


                int latitudeLines = 12;
                for (int j = 0; j <= latitudeLines; j++)
                {
                    GameObject latitude = new GameObject("latitude" + j);
                    latitude.transform.SetParent(gameObject.transform);
                    LineRenderer latLR = latitude.AddComponent<LineRenderer>();
                    latLR.positionCount = segments + 1;
                    latLR.useWorldSpace = true;
                    latLR.startWidth = 0.02f;
                    latLR.endWidth = 0.02f;
                    latLR.loop = true;
                    float theta = (float)j / latitudeLines * Mathf.PI;
                    float radius = planetRadius * Mathf.Sin(theta);
                    float y = planetRadius * Mathf.Cos(theta);
                    for (int i = 0; i <= segments; i++)
                    {
                        float angle = (float)i * 2f * Mathf.PI / segments;
                        Vector3 pos = vrrig.transform.TransformPoint(new Vector3(Mathf.Cos(angle) * radius, y, Mathf.Sin(angle) * radius));
                        latLR.SetPosition(i, pos);
                    }
                }


                GameObject ring = new GameObject("ring");
                ring.transform.SetParent(gameObject.transform);
                ring.transform.localRotation = Quaternion.Euler(ringTilt * Mathf.Rad2Deg, 0f, 0f);
                LineRenderer ringLR = ring.AddComponent<LineRenderer>();
                ringLR.positionCount = (segments + 1) * 2;
                ringLR.useWorldSpace = true;
                ringLR.startWidth = 0.02f;
                ringLR.endWidth = 0.02f;
                ringLR.loop = true;
                for (int i = 0; i <= segments; i++)
                {
                    float angle = (float)i * 2f * Mathf.PI / segments;
                    Vector3 innerPos = vrrig.transform.TransformPoint(new Vector3(Mathf.Cos(angle) * ringInnerRadius, 0f, Mathf.Sin(angle) * ringInnerRadius));
                    Vector3 outerPos = vrrig.transform.TransformPoint(new Vector3(Mathf.Cos(angle) * ringOuterRadius, 0f, Mathf.Sin(angle) * ringOuterRadius));
                    ringLR.SetPosition(i, innerPos);
                    ringLR.SetPosition(i + segments + 1, outerPos);
                }


                Color[] colors = { new Color(0f, 0f, 1f), new Color(0f, 1f, 0f), new Color(1f, 0f, 0f) };
                int colorIndex = Mathf.FloorToInt(Time.time % colors.Length);
                Color planetColor = colors[colorIndex];
                Color ringColor = new Color(1f, 0.8f, 0f);
                Shader shader = Shader.Find("GUI/Text Shader");

                foreach (Transform child in gameObject.transform)
                {
                    LineRenderer lr = child.GetComponent<LineRenderer>();
                    if (lr != null)
                    {
                        lr.material = new Material(shader);
                        if (child.name == "ring")
                            lr.startColor = ringColor;
                        else
                            lr.startColor = planetColor;
                        lr.endColor = lr.startColor;
                    }
                }

                gameObject.transform.LookAt(
                    gameObject.transform.position + Camera.main.transform.rotation * Vector3.forward,
                    Camera.main.transform.rotation * Vector3.up
                );
                UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
            }
        }
    }

}
