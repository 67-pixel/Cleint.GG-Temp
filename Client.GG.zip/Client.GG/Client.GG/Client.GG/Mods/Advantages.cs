﻿using ExitGames.Client.Photon;
using GorillaGameModes;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using static StupidTemplate.Menu.mods;

namespace TWOTIMEPAID.Mods
{
    class Advantages
    {
        public static void TagAura()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
                if (flag)
                {
                    bool flag2 = !vrrig.mainSkin.material.name.Contains("fected");
                    if (flag2)
                    {
                        bool flag3 = GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
                        if (flag3)
                        {
                            float num = Vector3.Distance(vrrig.bodyTransform.position, GTPlayer.Instance.bodyCollider.transform.position);
                            float num2 = 3.5f;
                            bool flag4 = num < num2;
                            if (flag4)
                            {
                                GTPlayer.Instance.headCollider.transform.position = vrrig.bodyTransform.position;
                                GTPlayer.Instance.rightControllerTransform.position = vrrig.bodyTransform.position;
                            }
                            GorillaTagger.Instance.maxTagDistance = float.MaxValue;
                        }
                    }
                }
            }
        }

        public static void AntiTag()
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
                if (flag)
                {
                    bool flag2 = vrrig.mainSkin.material.name.Contains("fected");
                    if (flag2)
                    {
                        bool flag3 = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
                        if (flag3)
                        {
                            float num = Vector3.Distance(vrrig.bodyTransform.position, GTPlayer.Instance.bodyCollider.transform.position);
                            float num2 = 3.5f;
                            bool flag4 = num < num2;
                            if (flag4)
                            {
                                GorillaTagger.Instance.offlineVRRig.enabled = false;
                                GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(float.PositiveInfinity, float.PositiveInfinity, float.PositiveInfinity);
                            }
                            else
                            {
                                GorillaTagger.Instance.offlineVRRig.enabled = true;
                            }
                        }
                    }
                }
            }
        }
    }
}

class SpamTagAll
{
    public static float Wait = -1f;
    public static void MatSpam()
    {
        float Wait = -1f;
        if (PhotonNetwork.LocalPlayer.IsMasterClient)
        {
            foreach (GorillaTagManager G in ObjectGroup.FindObjectsOfType<GorillaTagManager>())
            {
                foreach (Photon.Realtime.Player P in PhotonNetwork.PlayerList)
                {
                    if (Time.time > Wait + 0.1f)
                    {
                        if (G.currentInfected.Contains(P))
                        {
                            G.currentInfected.Remove(P);
                            G.ClearInfectionState();
                            G.UpdateState();
                        }
                        if (!G.currentInfected.Contains(P))
                        {
                            G.currentInfected.Add(P);
                            G.AddInfectedPlayer(P);
                            G.IsInfected(P);
                            G.UpdateState();
                        }
                    }
                }
            }
        }
        else
        {

            Debug.Log("<color=white>ERROR! NOT MASTER CLIENT</color>");

        }
    }
    public static void Changematspamdelayto0()
    {
        Wait = 0f;
    }

    public static void Changematspamdelayto1()
    {
        Wait = 1f;
    }

    public static void Changematspamdelayto2()
    {
        Wait = 2f;
    }

    public static void Changematspamdelayto10()
    {
        Wait = 10f;
    }


}

internal class NoTagFreeze
{
    public static void NoTagFreezeMod()
    {
        GorillaLocomotion.GTPlayer.Instance.disableMovement = false;
    }
}


class Notag
{
    public static void NoTagOnJoin()
    {
        PlayerPrefs.SetString("tutorial", "nope");
        PlayerPrefs.SetString("didTutorial", "nope");
        Hashtable hashtable = new Hashtable();
        hashtable.Add("didTutorial", false);
        PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, null, null);
        PlayerPrefs.Save();
    }
}

internal class Tag
{

    public static void TagAll()
    {
        bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
        if (flag)
        {
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag2 = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
                if (flag2)
                {
                    bool flag3 = !vrrig.mainSkin.material.name.Contains("fected");
                    if (flag3)
                    {
                        bool flag4 = GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
                        if (flag4)
                        {
                            GTPlayer.Instance.transform.position = vrrig.transform.position;
                            GTPlayer.Instance.rightControllerTransform.position = vrrig.transform.position;
                            foreach (MeshCollider meshCollider in UnityEngine.Object.FindObjectsOfType<MeshCollider>())
                            {
                                meshCollider.enabled = false;
                            }
                        }
                        else
                        {
                            Main.GetIndex("Tag All").enabled = false;
                            Main.RecreateMenu();
                        }
                    }
                }
            }
        }
        else
        {
            foreach (MeshCollider meshCollider2 in UnityEngine.Object.FindObjectsOfType<MeshCollider>())
            {
                meshCollider2.enabled = true;
            }
        }
    }
}

class TagAll
{
    public static void InstantTagAll()
    {
        if (PhotonNetwork.IsMasterClient)
        {
            foreach (Photon.Realtime.Player player in PhotonNetwork.PlayerList)
            {
                GorillaTagManager gtm = (GorillaTagManager)GorillaTagManager.instance;
                gtm.currentInfected.Add(player);
            }
        }
        else
        {
            Debug.LogError("<color=gray>ERROR! NOT MASTER CLIENT</color>");
        }
    }

    public static bool wait = false;

    public static void InstantTagGun()
    {
        GunTemplate.StartBothGuns(delegate
        {
            if (PhotonNetwork.IsMasterClient)
            {
                GorillaTagManager gtm = (GorillaTagManager)GorillaTagManager.instance;
                gtm.currentInfected.Add(VRRig.LocalRig.Creator);
            }
            else
            {
                Debug.LogError("<color=gray>ERROR! NOT MASTER CLIENT</color>");
            }
        }, true);
    }
}

