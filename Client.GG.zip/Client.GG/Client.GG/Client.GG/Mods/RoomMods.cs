﻿using GorillaNetworking;
using Photon.Pun;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace TwoTimePaid.Mods
{
    class Roomods
    {
        public static void JoinGHostCodes()
        {

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("RUN", 0);

            NotifiLib.SendNotification("<color=green>[JOINING RUN]</color> <color=white>Attempting to join RUN room...</color>");
        }
        public static void JoinD()
        {

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("DAISY09", 0);

            NotifiLib.SendNotification("<color=green>[JOINING DAISY09]</color> <color=white>Attempting to join DAISY09 room...</color>");
        }
        public static void JoinP()
        {

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("PBBV", 0);

            NotifiLib.SendNotification("<color=green>[JOINING PBBV]</color> <color=white>Attempting to join PBBV room...</color>");
        }
        public static void JoinE()
        {

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("ECHO", 0);

            NotifiLib.SendNotification("<color=green>[JOINING ECO]</color> <color=white>Attempting to join ECHO room...</color>");
        }
        public static void JoinH()
        {

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("HIDE", 0);

            NotifiLib.SendNotification("<color=green>[JOINING HIDE]</color> <color=white>Attempting to join HIDE room...</color>");
        }
        public static void JoinS()
        {

            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("SREN17", 0);

            NotifiLib.SendNotification("<color=green>[JOINING HIDE]</color> <color=white>Attempting to join HIDE room...</color>");
        }
    }
}

class JoinMM
{
    public static void JoinMMMod()
    {
        PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("UNTITLED", 0);
        NotifiLib.SendNotification("<color=green>[JOINING UNTITLED]</color> <color=white>Attempting to join TwoTimePaid! room...</color>");
    }
}
class random
{
    public static void JoinRandom()
    {
        bool Net = !PhotonNetwork.InRoom;
        if (Net)
        {
            PhotonNetworkController.Instance.AttemptToJoinPublicRoom(GorillaComputer.instance.GetJoinTriggerForZone(PhotonNetworkController.Instance.currentJoinTrigger.networkZone), 0);
        }
    }

}

class Diconnects
{
    public static void Disconnect()
    {
        bool Net = PhotonNetwork.InRoom;
        if (Net)
        {
            PhotonNetwork.Disconnect();
            NotifiLib.SendNotification("<color=red>[DISCONNECTED]</color> <color=white>You have disconnected from the server.</color>");
        }
    }
}

class DiffServers
{
    public static void EUServers()
    {
        PhotonNetwork.ConnectToRegion("eu");
    }


    public static void USServers()
    {
        PhotonNetwork.ConnectToRegion("us");
    }


    public static void USWServers()
    {
        PhotonNetwork.ConnectToRegion("usw");
    }
}