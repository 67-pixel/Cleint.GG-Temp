﻿using BepInEx;
using GorillaLocomotion;
using StupidTemplate.Menu;
using StupidTemplate.Patches;
using System;
using System.Collections.Generic;
using System.Text;
using TwoTimePaid.Mods;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using static StupidTemplate.Menu.mods;

namespace TwoTimePaid.Mods
{
    class Movement
    {
        public static void SpazMonke()
        {
            {
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 360));
                GorillaTagger.Instance.offlineVRRig.head.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.eulerAngles = new Vector3((float)UnityEngine.Random.Range(0, 360), (float)UnityEngine.Random.Range(0, 180), (float)UnityEngine.Random.Range(0, 180));
            }
        }
    }
}
internal class Punching
{

    public static void PunchMod()
    {
        int num = -1;
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
            bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
            bool flag2 = flag;
            if (flag2)
            {
                num++;
                bool flag3 = !Punching.Movement.lastRight.ContainsKey(num);
                if (flag3)
                {
                    Punching.Movement.lastRight[num] = vrrig.rightHandTransform.position;
                }
                bool flag4 = !Punching.Movement.lastLeft.ContainsKey(num);
                if (flag4)
                {
                    Punching.Movement.lastLeft[num] = vrrig.leftHandTransform.position;
                }
                Vector3 position = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
                Vector3 position2 = vrrig.rightHandTransform.position;
                float num2 = Vector3.Distance(position2, position);
                bool flag5 = num2 < 0.25f;
                if (flag5)
                {
                    Vector3 vector = Vector3.Normalize(position2 - Punching.Movement.lastRight[num]);
                    GTPlayer.Instance.GetComponent<Rigidbody>().velocity += vector * 10f;
                }
                Punching.Movement.lastRight[num] = position2;
                Vector3 position3 = vrrig.leftHandTransform.position;
                float num3 = Vector3.Distance(position3, position);
                bool flag6 = num3 < 0.25f;
                if (flag6)
                {
                    Vector3 vector2 = Vector3.Normalize(position3 - Punching.Movement.lastLeft[num]);
                    GTPlayer.Instance.GetComponent<Rigidbody>().velocity += vector2 * 10f;
                }
                Punching.Movement.lastLeft[num] = position3;
            }
        }
    }


    private static Punching.MovementData Movement = new Punching.MovementData();


    private class MovementData
    {

        public Dictionary<int, Vector3> lastRight = new Dictionary<int, Vector3>();


        public Dictionary<int, Vector3> lastLeft = new Dictionary<int, Vector3>();
    }
}



class IronMonke
{
    public static float _flySpeed = 10f;
    public static bool scaleWithPlayer;
    public static void IronMan()
    {
        Rigidbody rigidbody = GorillaTagger.Instance.rigidbody;
        if (ControllerInputPoller.instance.leftControllerPrimaryButton)
        {
            Vector3 vector = IronMonke.flySpeed * -GorillaTagger.Instance.leftHandTransform.right;
            rigidbody.AddForce(vector * Time.deltaTime, (ForceMode)2);
            float num = GorillaTagger.Instance.tapHapticStrength / 50f * rigidbody.velocity.magnitude;
            GorillaTagger.Instance.StartVibration(true, num, GorillaTagger.Instance.tapHapticDuration);
        }
        if (ControllerInputPoller.instance.rightControllerPrimaryButton)
        {
            Vector3 vector2 = IronMonke.flySpeed * GorillaTagger.Instance.rightHandTransform.right;
            rigidbody.AddForce(vector2 * Time.deltaTime, (ForceMode)2);
            float num2 = GorillaTagger.Instance.tapHapticStrength / 50f * rigidbody.velocity.magnitude;
            GorillaTagger.Instance.StartVibration(false, num2, GorillaTagger.Instance.tapHapticDuration);

        }
    }

    public static float flySpeed
    {
        get
        {
            return IronMonke._flySpeed * (IronMonke.scaleWithPlayer ? GTPlayer.Instance.scale : 1f);
        }
        set
        {
            IronMonke._flySpeed = value;
        }
    }
}

class WASDFlys
{

    public static void WASDFly()
    {
        GorillaTagger.Instance.rigidbody.velocity = new Vector3(0f, 0.067f, 0f);
        bool key = UnityInput.Current.GetKey((KeyCode)119);
        bool key2 = UnityInput.Current.GetKey((KeyCode)97);
        bool key3 = UnityInput.Current.GetKey((KeyCode)115);
        bool key4 = UnityInput.Current.GetKey((KeyCode)100);
        bool key5 = UnityInput.Current.GetKey((KeyCode)32);
        bool key6 = UnityInput.Current.GetKey((KeyCode)306);
        if (Mouse.current.rightButton.isPressed)
        {
            Transform parent = GTPlayer.Instance.rightControllerTransform.parent;
            Vector3 eulerAngles = parent.rotation.eulerAngles;
            if (Main.startX < 0f)
            {
                Main.startX = eulerAngles.y;
                Main.subThingy = Mouse.current.position.value.x / (float)Screen.width;
            }
            if (Main.startY < 0f)
            {
                Main.startY = eulerAngles.x;
                Main.subThingyZ = Mouse.current.position.value.y / (float)Screen.height;
            }
            float num = Main.startY - (Mouse.current.position.value.y / (float)Screen.height - Main.subThingyZ) * 360f * 1.33f;
            float num2 = Main.startX + (Mouse.current.position.value.x / (float)Screen.width - Main.subThingy) * 360f * 1.33f;
            num = ((num > 180f) ? (num - 360f) : num);
            num = Mathf.Clamp(num, -90f, 90f);
            parent.rotation = Quaternion.Euler(num, num2, eulerAngles.z);
        }
        else
        {
            Main.startX = -1f;
            Main.startY = -1f;
        }
        float num3 = Main.flySpeed;
        if (UnityInput.Current.GetKey((KeyCode)304))
        {
            num3 *= 2f;
        }
        if (key)
        {
            GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.forward * Time.deltaTime * num3;
        }
        if (key3)
        {
            GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.forward * Time.deltaTime * -num3;
        }
        if (key2)
        {
            GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.right * Time.deltaTime * -num3;
        }
        if (key4)
        {
            GorillaTagger.Instance.rigidbody.transform.position += GTPlayer.Instance.rightControllerTransform.parent.right * Time.deltaTime * num3;
        }
        if (key5)
        {
            GorillaTagger.Instance.rigidbody.transform.position += new Vector3(0f, Time.deltaTime * num3, 0f);
        }
        if (key6)
        {
            GorillaTagger.Instance.rigidbody.transform.position += new Vector3(0f, Time.deltaTime * -num3, 0f);
        }
    }
}

class UpsideMod
{
    public static void UpsideDowm()
    {
        if (ControllerInputPoller.instance.rightGrab)
        {
            Physics.gravity = new Vector3(0, 9.81f, 0);
        }
        else
        {
            Physics.gravity = new Vector3(0, -9.81f, 0);
        }
    }
}


class griddy
{
    public static void AutoGriddy()
    {
        if (ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.leftButton.isPressed)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;

            Vector3 bodyOffset = GorillaTagger.Instance.offlineVRRig.transform.forward * (5f * Time.deltaTime);
            GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + bodyOffset;
            try
            {
                GorillaTagger.Instance.myVRRig.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + bodyOffset;
            }
            catch { }

            GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;

            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + (GorillaTagger.Instance.offlineVRRig.transform.right * -0.33f) + (GorillaTagger.Instance.offlineVRRig.transform.forward * (0.5f * Mathf.Cos((float)Time.frameCount / 10f))) + (GorillaTagger.Instance.offlineVRRig.transform.up * (-0.5f * Mathf.Abs(Mathf.Sin((float)Time.frameCount / 10f))));
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + (GorillaTagger.Instance.offlineVRRig.transform.right * 0.33f) + (GorillaTagger.Instance.offlineVRRig.transform.forward * (0.5f * Mathf.Cos((float)Time.frameCount / 10f))) + (GorillaTagger.Instance.offlineVRRig.transform.up * (-0.5f * Mathf.Abs(Mathf.Sin((float)Time.frameCount / 10f))));

            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }
}

class autodance
{
    public static void AutoDance()
    {
        if (ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.leftButton.isPressed)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;

            Vector3 bodyOffset = (GorillaTagger.Instance.bodyCollider.transform.right * (Mathf.Cos((float)Time.frameCount / 20f) * 0.3f)) + (new Vector3(0f, Mathf.Abs(Mathf.Sin((float)Time.frameCount / 20f) * 0.2f), 0f));
            GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f) + bodyOffset;
            try
            {
                GorillaTagger.Instance.myVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f) + bodyOffset;
            }
            catch { }

            GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
            try
            {
                GorillaTagger.Instance.myVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
            }
            catch { }

            GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;

            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.forward * 0.2f + GorillaTagger.Instance.offlineVRRig.transform.right * -0.4f + GorillaTagger.Instance.offlineVRRig.transform.up * (0.3f + (Mathf.Sin((float)Time.frameCount / 20f) * 0.2f));
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.offlineVRRig.transform.position + GorillaTagger.Instance.offlineVRRig.transform.forward * 0.2f + GorillaTagger.Instance.offlineVRRig.transform.right * 0.4f + GorillaTagger.Instance.offlineVRRig.transform.up * (0.3f + (Mathf.Sin((float)Time.frameCount / 20f) * -0.2f));

            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }
}

class Plats
{
    public static void PlatformMod()

    {
        if (ControllerInputPoller.instance.leftGrab && leftplat == null)
        {
            leftplat = CreatePlatformOnHand(GorillaTagger.Instance.leftHandTransform);
        }

        if (ControllerInputPoller.instance.rightGrab && rightplat == null)
        {
            rightplat = CreatePlatformOnHand(GorillaTagger.Instance.rightHandTransform);
        }

        if (ControllerInputPoller.instance.rightGrabRelease && rightplat != null)
        {
            rightplat.Disable();
            rightplat = null;

        }

        if (ControllerInputPoller.instance.leftGrabRelease && leftplat != null)
        {
            leftplat.Disable();
            leftplat = null;
        }
    }
    private static GameObject leftplat = null;
    private static GameObject rightplat = null;
    private static GameObject CreatePlatformOnHand(Transform handTransform)
    {
        GameObject plat = GameObject.CreatePrimitive(PrimitiveType.Cube);
        plat.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);

        plat.transform.position = handTransform.position;
        plat.transform.rotation = handTransform.rotation;

        float h = (Time.frameCount / 180f) % 1f;
        plat.GetComponent<Renderer>().material.color = Color.gray1;
        return plat;
    }
}

internal class Invis_Platform
{
    public static void InvisPlatformMod()

    {
        if (ControllerInputPoller.instance.leftGrab && leftplat == null)
        {
            leftplat = CreatePlatformOnHand(GorillaTagger.Instance.leftHandTransform);
        }

        if (ControllerInputPoller.instance.rightGrab && rightplat == null)
        {
            rightplat = CreatePlatformOnHand(GorillaTagger.Instance.rightHandTransform);
        }

        if (ControllerInputPoller.instance.rightGrabRelease && rightplat != null)
        {
            rightplat.Disable();
            rightplat = null;

        }

        if (ControllerInputPoller.instance.leftGrabRelease && leftplat != null)
        {
            leftplat.Disable();
            leftplat = null;
        }
    }
    private static GameObject leftplat = null;
    private static GameObject rightplat = null;
    private static GameObject CreatePlatformOnHand(Transform handTransform)
    {
        GameObject plat = GameObject.CreatePrimitive(PrimitiveType.Cube);
        plat.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);

        plat.transform.position = handTransform.position;
        plat.transform.rotation = handTransform.rotation;

        // Get the renderer and apply transparent material
        Renderer renderer = plat.GetComponent<Renderer>();
        if (renderer != null)
        {
            Material transparentMaterial = new Material(Shader.Find("Standard"));
            transparentMaterial.color = new Color(1f, 1f, 1f, 0f); // Fully transparent
            transparentMaterial.SetFloat("_Mode", 2); // Set to transparent mode
            transparentMaterial.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            transparentMaterial.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            transparentMaterial.SetInt("_ZWrite", 0);
            transparentMaterial.DisableKeyword("_ALPHATEST_ON");
            transparentMaterial.EnableKeyword("_ALPHABLEND_ON");
            transparentMaterial.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            transparentMaterial.renderQueue = 3000;

            renderer.material = transparentMaterial;
        }

        return plat;
    }
}



class NoClip
{
    public static void NoClipMod()
    {
        bool disableColliders = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
        MeshCollider[] colliders = Resources.FindObjectsOfTypeAll<MeshCollider>();

        foreach (MeshCollider collider in colliders)
        {
            collider.enabled = !disableColliders;
        }
    }
}

class Gravity
{
    public static void HighGravity()
    {
        GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.down * (Time.unscaledDeltaTime * (7.77f / Time.unscaledDeltaTime)), (ForceMode)5);
    }


}
class NoGravity
{
    public static void ZeroGravity()
    {
        GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.unscaledDeltaTime * (9.81f / Time.unscaledDeltaTime)), (ForceMode)5);
    }
    public static void ReverseGravity()
    {
        GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (19.62f / Time.deltaTime)), (ForceMode)5);
        GTPlayer.Instance.rightControllerTransform.parent.rotation = Quaternion.Euler(180f, 0f, 0f);
    }
}


class WalkingWall
{
    public static void wallwalk()
    {
        bool flag = ControllerInputPoller.GripFloat((XRNode)5) == 1f;
        if (flag)
        {
            GorillaLocomotion.GTPlayer.Instance.bodyCollider.attachedRigidbody.velocity += GorillaLocomotion.GTPlayer.Instance.bodyCollider.transform.right / 7f;
        }
        bool flag2 = ControllerInputPoller.GripFloat((XRNode)4) == 1f;
        if (flag2)
        {
            GorillaLocomotion.GTPlayer.Instance.bodyCollider.attachedRigidbody.velocity += -GorillaLocomotion.GTPlayer.Instance.bodyCollider.transform.right / 7f;
        }
    }
}


public class RigBrag
{
    public static void GrabRig()
    {
        GhostPatch.Prefix(GorillaTagger.Instance.offlineVRRig);
        GhostPatch2.Prefix(VRRigJobManager.Instance, GorillaTagger.Instance.offlineVRRig);
        bool flag = ControllerInputPoller.instance.rightGrab;
        if (flag)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.rightControllerTransform.position;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
        bool leftGrab = ControllerInputPoller.instance.leftGrab;
        if (leftGrab)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.leftControllerTransform.position;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
        bool flag2 = ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f;
        if (flag2)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.leftControllerTransform.position;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
        bool flag3 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
        if (flag3)
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.rightControllerTransform.position;
        }
        else
        {
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }
    }

}


class FrozeMod
{
    public static void FrozoneMod()
    {
        bool leftGrab = ControllerInputPoller.instance.leftGrab;
        if (leftGrab)
        {
            GameObject gameObject = GameObject.CreatePrimitive((PrimitiveType)3);
            gameObject.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
            gameObject.transform.localPosition = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, -0.05f, 0f);
            gameObject.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
            gameObject.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
            gameObject.GetComponent<Renderer>().material.color = Color.softRed;
            UnityEngine.Object.Destroy(gameObject, 0.3f);
        }
        bool flag = ControllerInputPoller.instance.rightGrab;
        if (flag)
        {
            GameObject gameObject2 = GameObject.CreatePrimitive((PrimitiveType)3);
            gameObject2.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
            gameObject2.transform.localPosition = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, -0.05f, 0f);
            gameObject2.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
            gameObject2.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
            gameObject2.GetComponent<Renderer>().material.color = Color.softRed;
            UnityEngine.Object.Destroy(gameObject2, 0.3f);
        }
    }

}

class AutoClimb
{
    public static void AutoElevatorClimbMod()
    {
        bool flag = ControllerInputPoller.instance.rightControllerSecondaryButton || Mouse.current.leftButton.isPressed;
        if (flag)
        {
            float num = (float)Time.frameCount / 3f;
            GorillaTagger.Instance.rightHandTransform.position = GorillaTagger.Instance.headCollider.transform.position + GorillaTagger.Instance.headCollider.transform.right * (0.4f + MathF.Cos(num) * 0.4f) + GorillaTagger.Instance.headCollider.transform.up * (MathF.Sin(num) * 0.6f) + GorillaTagger.Instance.headCollider.transform.forward * 0.75f;
        }
    }


    public static void AutoPinchClimbMod()
    {
        bool flag = ControllerInputPoller.instance.rightControllerSecondaryButton || Mouse.current.leftButton.isPressed;
        if (flag)
        {
            float num = (float)Time.frameCount / 3f;
            GorillaTagger.Instance.rightHandTransform.position = GorillaTagger.Instance.headCollider.transform.position + GorillaTagger.Instance.headCollider.transform.right * (0.4f + MathF.Cos(num) * 0.4f) + GorillaTagger.Instance.headCollider.transform.up * (MathF.Sin(num) * 0.6f) + GorillaTagger.Instance.headCollider.transform.forward * 0.75f;
            GorillaTagger.Instance.leftHandTransform.position = GorillaTagger.Instance.headCollider.transform.position + GorillaTagger.Instance.headCollider.transform.right * -(0.4f + MathF.Cos(num) * 0.4f) + GorillaTagger.Instance.headCollider.transform.up * (MathF.Sin(num) * 0.6f) + GorillaTagger.Instance.headCollider.transform.forward * 0.75f;
        }
    }
}

class CarMonkeMod
{

    public static void CarMonke()
    {
        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f)
        {
            GorillaLocomotion.GTPlayer.Instance.transform.position += GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 15f;
        }

        if (ControllerInputPoller.instance.rightGrab)
        {
            GorillaLocomotion.GTPlayer.Instance.transform.position -= GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 20f;
        }
    }
}



class Flying
{
    public static void FlyMod()
    {
        if (ControllerInputPoller.instance.rightControllerSecondaryButton || Mouse.current.rightButton.isPressed)
        {
            GorillaLocomotion.GTPlayer.Instance.transform.position += (GorillaLocomotion.GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime) * 15f;
            GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
    }
    public static void flywithnoclip()
    {
        if (ControllerInputPoller.instance.rightControllerSecondaryButton || Mouse.current.rightButton.isPressed)

        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 17f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = GTPlayer.Instance.rightControllerTransform.forward * 20f;
            foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
            {
                meshCollider.enabled = false;
            }
        }
        else
        {
            foreach (MeshCollider meshCollider2 in Resources.FindObjectsOfTypeAll<MeshCollider>())
            {
                meshCollider2.enabled = true;
            }
        }
    }

}


class Joyfly
{
    public static void FastJoystickFly()
    {
        bool flag = ControllerInputPoller.instance.rightControllerPrimary2DAxis.y > 0.5f;
        if (flag)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 15f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool flag2 = ControllerInputPoller.instance.rightControllerPrimary2DAxis.y < -0.5f;
        if (flag2)
        {
            GTPlayer.Instance.transform.position -= GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 15f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool flag3 = ControllerInputPoller.instance.rightControllerPrimary2DAxis.x < -0.5f;
        if (flag3)
        {
            GTPlayer.Instance.transform.position -= GTPlayer.Instance.headCollider.transform.right * Time.deltaTime * 15f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool flag4 = ControllerInputPoller.instance.rightControllerPrimary2DAxis.x > 0.5f;
        if (flag4)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.right * Time.deltaTime * 15f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool flag5 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
        if (flag5)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.transform.up * Time.deltaTime * 15f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool flag6 = ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f;
        if (flag6)
        {
            GTPlayer.Instance.transform.position -= GTPlayer.Instance.transform.up * Time.deltaTime * 15f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Vector3.up * (Time.deltaTime * (9.81f / Time.deltaTime)), (ForceMode)5);
        GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * 0f;
        GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
    }

}

class TrigFly
{
    public static void TriggerFlyMod()
    {
        bool flag = (double)ControllerInputPoller.instance.rightControllerIndexFloat > 0.1;
        if (flag)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.rightControllerTransform.transform.forward * Time.deltaTime * 20f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool isPressed = Mouse.current.rightButton.isPressed;
        if (isPressed)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 20f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
    }
    public static void TriggerSlowFlyMod()
    {
        bool flag = (double)ControllerInputPoller.instance.rightControllerIndexFloat > 0.1;
        if (flag)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.rightControllerTransform.transform.forward * Time.deltaTime * 10f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
        bool isPressed = Mouse.current.rightButton.isPressed;
        if (isPressed)
        {
            GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 10f;
            GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
        }
    }
}

class XYHEAD
{
    public static void SpinHeadXMod()
    {
        VRMap head = GorillaTagger.Instance.offlineVRRig.head;
        head.trackingRotationOffset.x = head.trackingRotationOffset.x + 10f;
    }

    public static void SpinHeadYMod()
    {
        VRMap head = GorillaTagger.Instance.offlineVRRig.head;
        head.trackingRotationOffset.y = head.trackingRotationOffset.y + 10f;
    }

    public static void SpinHeadZMod()
    {
        VRMap head = GorillaTagger.Instance.offlineVRRig.head;
        head.trackingRotationOffset.z = head.trackingRotationOffset.z + 10f;
    }
}


class TPGun
{
    public static GameObject GunSphere;
    private static LineRenderer lineRenderer;
    private static float timeCounter = 0f;
    private static Vector3[] linePositions;
    private static Vector3 previousControllerPosition;

    public static float num = 10f;

    public static void GunSmoothNess()
    {
        if (num == 10f)
            num = 15f;  // Super smooth (slower)
        else if (num == 15f)
            num = 5f;   // Fast (no smoothness)
        else
            num = 10f;  // Normal smoothness
    }

    // List of colors to cycle through
    public static List<(Color color, string name)> colorCycle = new List<(Color, string)>
{
(Color.darkRed, "maincolor"),

};

    public static (Color color, string name) currentGunColor = colorCycle[0];

    // Method to cycle through the colors
    public static void CycleGunColor()
    {
        int currentIndex = colorCycle.IndexOf(currentGunColor);
        currentGunColor = colorCycle[(currentIndex + 1) % colorCycle.Count];
    }

    public static bool isSphereEnabled = true;


    public static void GunTemplate()
    {
        if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
        {
            if (Physics.Raycast(GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position, -GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.up, out var hitinfo))
            {
                if (Mouse.current.rightButton.isPressed)
                {
                    Camera cam = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                    Ray ray = cam.ScreenPointToRay(Mouse.current.position.ReadValue());
                    Physics.Raycast(ray, out hitinfo, 100);
                }

                if (GunSphere == null)
                {
                    GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    GunSphere.transform.localScale = isSphereEnabled ? new Vector3(0.1f, 0.1f, 0.1f) : new Vector3(0f, 0f, 0f);
                    GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    GunSphere.GetComponent<Renderer>().material.color = currentGunColor.color;  // Set initial color
                    GameObject.Destroy(GunSphere.GetComponent<BoxCollider>());
                    GameObject.Destroy(GunSphere.GetComponent<Rigidbody>());
                    GameObject.Destroy(GunSphere.GetComponent<Collider>());

                    lineRenderer = GunSphere.AddComponent<LineRenderer>();
                    lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
                    lineRenderer.widthCurve = AnimationCurve.Linear(0, 0.01f, 1, 0.01f);
                    lineRenderer.startColor = currentGunColor.color;  // Set initial color
                    lineRenderer.endColor = currentGunColor.color;

                    linePositions = new Vector3[50];
                    for (int i = 0; i < linePositions.Length; i++)
                    {
                        linePositions[i] = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                    }
                }

                GunSphere.transform.position = hitinfo.point;

                timeCounter += Time.deltaTime;

                Vector3 pos1 = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                Vector3 direction = (hitinfo.point - pos1).normalized;
                float distance = Vector3.Distance(pos1, hitinfo.point);

                Vector3 controller = pos1 - previousControllerPosition;
                previousControllerPosition = pos1;

                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || Mouse.current.leftButton.isPressed)
                {
                    Vector3 targetPos = hitinfo.point;
                    targetPos.y += 0.1f; // lift slightly above ground

                    GorillaLocomotion.GTPlayer.Instance.transform.position = targetPos;

                    Rigidbody rb = GorillaLocomotion.GTPlayer.Instance.GetComponent<Rigidbody>();
                    if (rb != null)
                        rb.velocity = Vector3.zero; // stop momentum
                }


                for (int i = 0; i < linePositions.Length; i++)
                {
                    float t = i / (float)(linePositions.Length - 1);
                    Vector3 linePos = Vector3.Lerp(pos1, hitinfo.point, t);

                    linePositions[i] += controller * 0.5f;
                    linePositions[i] += UnityEngine.Random.insideUnitSphere * 0.01f;
                    linePositions[i] = Vector3.Lerp(linePositions[i], linePos, Time.deltaTime * num);
                }

                lineRenderer.positionCount = linePositions.Length;
                lineRenderer.SetPositions(linePositions);

                // Apply the current color to the gun and the line renderer
                GunSphere.GetComponent<Renderer>().material.color = currentGunColor.color;
                lineRenderer.startColor = currentGunColor.color;
                lineRenderer.endColor = currentGunColor.color;
            }
        }

        if (GunSphere != null && (ControllerInputPoller.instance.rightControllerGripFloat <= 0.1f && !UnityInput.Current.GetMouseButton(1)))
        {
            GameObject.Destroy(GunSphere);
            GameObject.Destroy(lineRenderer);
            timeCounter = 0f;
            linePositions = null;
        }
    }

}




class PlatGun
{
    public static GameObject GunSphere;
    public static GameObject GunPlatform; // the platform attached to the sphere
    private static LineRenderer lineRenderer;
    private static Vector3[] linePositions;
    private static Vector3 previousControllerPosition;
    private static float timeCounter = 0f;

    public static float num = 10f;

    public static List<(Color color, string name)> colorCycle = new List<(Color, string)>
    {
        (new Color(0.5f, 0f, 0f), "Dark Red")
    };

    public static (Color color, string name) currentGunColor = colorCycle[0];

    public static void CycleGunColor()
    {
        int currentIndex = colorCycle.IndexOf(currentGunColor);
        currentGunColor = colorCycle[(currentIndex + 1) % colorCycle.Count];
    }

    public static bool isSphereEnabled = true;

    public static void GunTemplate()
    {
        // Grip -> show gun
        if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
        {
            if (Physics.Raycast(GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position,
                                -GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.up,
                                out var hitinfo))
            {
                // create gun sphere
                if (GunSphere == null)
                {
                    GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    GunSphere.transform.localScale = isSphereEnabled ? new Vector3(0.1f, 0.1f, 0.1f) : Vector3.zero;
                    GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    GunSphere.GetComponent<Renderer>().material.color = currentGunColor.color;
                    GameObject.Destroy(GunSphere.GetComponent<Collider>());
                    GameObject.Destroy(GunSphere.GetComponent<Rigidbody>());

                    // line
                    lineRenderer = GunSphere.AddComponent<LineRenderer>();
                    lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
                    lineRenderer.widthCurve = AnimationCurve.Linear(0, 0.01f, 1, 0.01f);

                    linePositions = new Vector3[50];
                    for (int i = 0; i < linePositions.Length; i++)
                        linePositions[i] = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                }

                // move sphere
                GunSphere.transform.position = hitinfo.point;

                // ---------- PLATFORM CREATION ----------
                if (GunPlatform == null)
                {
                    GunPlatform = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    GunPlatform.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
                    GunPlatform.GetComponent<Renderer>().material.color = currentGunColor.color;
                    GameObject.Destroy(GunPlatform.GetComponent<Rigidbody>()); // no physics
                }

                // make platform follow the sphere
                GunPlatform.transform.position = GunSphere.transform.position;
                GunPlatform.transform.rotation = GunSphere.transform.rotation;

                // update line
                timeCounter += Time.deltaTime;
                Vector3 pos1 = GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position;
                Vector3 controller = pos1 - previousControllerPosition;
                previousControllerPosition = pos1;

                for (int i = 0; i < linePositions.Length; i++)
                {
                    float t = i / (float)(linePositions.Length - 1);
                    Vector3 linePos = Vector3.Lerp(pos1, hitinfo.point, t);
                    linePositions[i] += controller * 0.5f;
                    linePositions[i] += UnityEngine.Random.insideUnitSphere * 0.01f;
                    linePositions[i] = Vector3.Lerp(linePositions[i], linePos, Time.deltaTime * num);
                }

                lineRenderer.positionCount = linePositions.Length;
                lineRenderer.SetPositions(linePositions);

                // update colors
                GunSphere.GetComponent<Renderer>().material.color = currentGunColor.color;
                lineRenderer.startColor = currentGunColor.color;
                lineRenderer.endColor = currentGunColor.color;
                GunPlatform.GetComponent<Renderer>().material.color = currentGunColor.color;
            }
        }
        else
        {
            // Release grip -> cleanup
            if (GunSphere != null) GameObject.Destroy(GunSphere);
            if (lineRenderer != null) GameObject.Destroy(lineRenderer);
            if (GunPlatform != null) GameObject.Destroy(GunPlatform);
            GunSphere = null;
            GunPlatform = null;
            lineRenderer = null;
            timeCounter = 0f;
            linePositions = null;
        }
    }
}
class CopyMovementGUN
{
    public static VRRig LockedRigOrPlayerOrwhatever;
    public static void CopyMovementGun()
    {
        GunTemplate.StartBothGuns(delegate
        {
            GorillaTagger.Instance.offlineVRRig.enabled = false;
            GorillaTagger.Instance.offlineVRRig.transform.position = CopyMovementGUN.LockedRigOrPlayerOrwhatever.transform.position;
            GorillaTagger.Instance.offlineVRRig.transform.rotation = CopyMovementGUN.LockedRigOrPlayerOrwhatever.transform.rotation;
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = CopyMovementGUN.LockedRigOrPlayerOrwhatever.leftHandTransform.position;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = CopyMovementGUN.LockedRigOrPlayerOrwhatever.rightHandTransform.position;
            GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = CopyMovementGUN.LockedRigOrPlayerOrwhatever.leftHandTransform.rotation;
            GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = CopyMovementGUN.LockedRigOrPlayerOrwhatever.rightHandTransform.rotation;
            GorillaTagger.Instance.offlineVRRig.enabled = true;
        }, true);
    }

}
