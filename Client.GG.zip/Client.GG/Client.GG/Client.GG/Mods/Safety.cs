﻿using GorillaNetworking;
using Photon.Pun;
using PlayFab.ClientModels;
using PlayFab;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;
using ExitGames.Client.Photon;
using AetherTemp.Menu;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate;
using PlayFab.ExperimentationModels;

namespace TwoTimePaid.Mods
{
    class Safety
    {
        public static void NoFinger()
        {
            ControllerInputPoller.instance.leftControllerGripFloat = 0f;
            ControllerInputPoller.instance.rightControllerGripFloat = 0f;
            ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
            ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
            ControllerInputPoller.instance.leftControllerPrimaryButton = false;
            ControllerInputPoller.instance.leftControllerSecondaryButton = false;
            ControllerInputPoller.instance.rightControllerPrimaryButton = false;
            ControllerInputPoller.instance.rightControllerSecondaryButton = false;
        }

    }
}

class XTdisconnect
{
    public static void XToDisconnectMod()
    {
        bool leftControllerPrimaryButton = ControllerInputPoller.instance.leftControllerPrimaryButton;
        if (leftControllerPrimaryButton)
        {
            PhotonNetwork.Disconnect();
        }
    }

}

class disguise
{
    public static void Disguise()
    {
        // 1. Change the nicknames to disguise as different players.
        PhotonNetwork.NickName = "LONG";
        PhotonNetwork.NetworkingClient.NickName = "MINIGAMES";
        PhotonNetwork.LocalPlayer.NickName = "JEFF";
    }
}

class ModeratorAnti
{
    public static void AntiModerator()
    {
        // Loop through all players in the room
        foreach (var vrrig in GorillaParent.instance.vrrigs)
        {
            // Skip if it's an offline rig (not a real player)
            if (vrrig.isOfflineVRRig)
                continue;

            // Check if the player's cosmetics contain "LBAAK" (moderator cosmetic)
            bool isModerator = vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAK");
            if (isModerator)
            {
                // Send notification that a moderator joined
                NotifiLib.SendNotification("<color=red>[ANTI-MODERATOR]</color> Some One with the moderator stick joined");

                // Disconnect immediately
                PhotonNetwork.Disconnect();

                // Stop checking further
                break;
            }
        }
    }
}

public static class banAnti
{
    public static void AntiBan()
    {
        bool inRoom = PhotonNetwork.InRoom;
        if (inRoom)
        {
            bool flag = !banAnti.IsModded();
            if (flag)
            {
                bool flag2 = !PhotonNetwork.CurrentRoom.IsOpen;
                if (flag2)
                {
                    NotifiLib.SendNotification("<color=grey>[</color><color=red>ANTIBAN</color><color=grey>]</color> <color=white>Anti ban has already been used in this code.</color>");
                }
                else
                {
                    string text = PhotonNetwork.CurrentRoom.CustomProperties["gameMode"].ToString().Replace(GorillaComputer.instance.currentGameMode.Value, "MODDED_MODDED" + GorillaComputer.instance.currentGameMode.Value);
                    Hashtable hashtable = new Hashtable();
                    hashtable.Add("gameMode", text);
                    Hashtable hashtable2 = hashtable;
                    NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTIBAN</color><color=grey>]</color> <color=white>Setting master client...</color>");
                    PhotonNetwork.SetMasterClient(PhotonNetwork.LocalPlayer);
                    PhotonNetwork.CurrentRoom.IsOpen = false;
                    PhotonNetwork.CurrentRoom.IsVisible = false;
                    NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTIBAN</color><color=grey>]</color> <color=white>Setting gamemode...</color>");
                    PhotonNetwork.CurrentRoom.SetCustomProperties(hashtable2, null, null);
                    ExecuteCloudScriptRequest executeCloudScriptRequest = new ExecuteCloudScriptRequest();
                    executeCloudScriptRequest.FunctionName = "RoomClosed";
                    executeCloudScriptRequest.FunctionParameter = new
                    {
                        GameId = PhotonNetwork.CurrentRoom.Name,
                        Region = Regex.Replace(PhotonNetwork.CloudRegion, "[^a-zA-Z0-9]", "").ToUpper(),
                        ActorNr = PhotonNetwork.LocalPlayer.ActorNumber,
                        ActorCount = 0,
                        UserId = PhotonNetwork.LocalPlayer.UserId,
                        AppVersion = PhotonNetwork.AppVersion,
                        AppId = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime,
                        Type = "Close"
                    };
                    PlayFabClientAPI.ExecuteCloudScript(executeCloudScriptRequest, delegate (ExecuteCloudScriptResult result)
                    {
                        NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTIBAN</color><color=grey>]</color> <color=white>Anti ban has been executed successfully. I take no responsibility for any bans using this mod.</color>");
                    }, delegate (PlayFabError error)
                    {
                        NotifiLib.SendNotification("<color=grey>[</color><color=red>ANTIBAN</color><color=grey>]</color> <color=white>Anti ban has failed to execute, you have been disconnected to prevent any bans.");
                        PhotonNetwork.Disconnect();
                    }, null, null);
                }
            }
            else
            {
                NotifiLib.SendNotification("<color=grey>[</color><color=red>ANTIBAN</color><color=grey>]</color> <color=white>Anti ban has already been used in this lobby.</color>");
            }
        }
    }
    public static bool IsModded()
    {
        return false;
    }
}


class RPCANTI
{
    public static void AntiRPC()
    {
        // 1. Increase important network-related limits to avoid getting disconnected or detected.
        GorillaNot.instance.rpcCallLimit = int.MaxValue;
        GorillaNot.instance.rpcErrorMax = int.MaxValue;
        GorillaNot.instance.logErrorMax = int.MaxValue;

        PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
        PhotonNetwork.QuickResends = int.MaxValue;

        // 2. Remove all RPCs and clean up RPC buffers.
        PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
        PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig.GetView);
        PhotonNetwork.RemoveBufferedRPCs(GorillaTagger.Instance.myVRRig.ViewID, null, null);
        PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);

        // 3. Send any remaining outgoing commands to finalize the cleanup.
        PhotonNetwork.SendAllOutgoingCommands();

        // 4. Inform GorillaNot to treat us as if we've left the room to avoid network calls.
        GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
    }
}

class ReportMods
{
    public static void antireport()
    {
        {
            foreach (GorillaPlayerScoreboardLine line in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                if (line.linePlayer == NetworkSystem.Instance.LocalPlayer)
                {
                    Transform report = line.reportButton.gameObject.transform;
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        if (vrrig != GorillaTagger.Instance.offlineVRRig)
                        {
                            float D1 = Vector3.Distance(vrrig.rightHandTransform.position, report.position);
                            float D2 = Vector3.Distance(vrrig.leftHandTransform.position, report.position);

                            float threshold = 0.35f;

                            if (D1 < threshold || D2 < threshold)
                            {
                                PhotonNetwork.Disconnect();
                                RPCprotection();
                                NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> <color=white>Someone attempted to report you, you have been disconnected.</color>");
                            }
                        }
                    }
                }
            }
        }
    }

    private static void RPCprotection()
    {
        throw new NotImplementedException();
    }
    public static void AntiReportReconnect()
    {
        try
        {
            foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                bool flag = gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer;
                if (flag)
                {
                    Transform transform = gorillaPlayerScoreboardLine.reportButton.gameObject.transform;
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        bool flag2 = vrrig != GorillaTagger.Instance.offlineVRRig;
                        if (flag2)
                        {
                            float num = Vector3.Distance(vrrig.rightHandTransform.position, transform.position);
                            float num2 = Vector3.Distance(vrrig.leftHandTransform.position, transform.position);
                            float num3 = 0.35f;
                            bool flag3 = num < num3 || num2 < num3;
                            if (flag3)
                            {
                                PhotonNetwork.Reconnect();
                                NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> <color=white>Someone attempted to report you, you have been reconnected.</color>");
                            }
                        }
                    }
                }
            }
        }
        catch
        {
        }
    }
    public static void AntiReportJoinRandom()
    {
        try
        {
            foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                bool flag = gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer;
                if (flag)
                {
                    Transform transform = gorillaPlayerScoreboardLine.reportButton.gameObject.transform;
                    foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                    {
                        bool flag2 = vrrig != GorillaTagger.Instance.offlineVRRig;
                        if (flag2)
                        {
                            float num = Vector3.Distance(vrrig.rightHandTransform.position, transform.position);
                            float num2 = Vector3.Distance(vrrig.leftHandTransform.position, transform.position);
                            float num3 = 0.35f;
                            bool flag3 = num < num3 || num2 < num3;
                            if (flag3)
                            {
                                PhotonNetwork.JoinRandomRoom();
                                NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> <color=white>Someone attempted to report you, you have been connected to a random lobby..</color>");
                            }
                        }
                    }
                }
            }
        }
        catch
        {
        }
    }
}

class CheckMas
{

    public static void SetMasterMod()
    {
        bool isMasterClient = PhotonNetwork.IsMasterClient;
        bool flag = isMasterClient;
        if (flag)
        {
            NotifiLib.SendNotification("<color=green>Your already Master Client</color>");
        }
        else
        {
            NotifiLib.SendNotification("<color=red>Your not master Client</color>");
        }
    }

}


class game
{
    public static void RestartGame()
    {
        Process.Start("steam://rungameid/1533390");
        Application.Quit();
    }
    public static void FakeOculusMenu()
    {
        bool rightGrab = ControllerInputPoller.instance.rightGrab;
        if (rightGrab)
        {
            GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.position = GorillaTagger.Instance.bodyCollider.transform.position;
            GorillaLocomotion.GTPlayer.Instance.leftControllerTransform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
            GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.position = GorillaTagger.Instance.bodyCollider.transform.position;
            GorillaLocomotion.GTPlayer.Instance.rightControllerTransform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
        }
    }

}

internal class Quit
{
    public static void QuitGameMod()
    {
        Application.Quit();
    }
}


class FPS
{
    public static void CapFPS123()
    {
        Application.targetFrameRate = 145;
    }
    public static void FPS1()
    {
        Application.targetFrameRate = 90;
    }
    public static void FPS2()
    {
        Application.targetFrameRate = 60;
    }
    public static void FPSDefault()
    {
        Application.targetFrameRate = -1;

    }


}


class Disable
{
    public static void Panic()
    {

        foreach (ButtonInfo[] array in Buttons.buttons)
        {
            foreach (ButtonInfo buttonInfo in array)
            {
                if (buttonInfo.enabled)
                {
                    Main.Toggle(buttonInfo.buttonText, false, false);
                }
            }
        }
    }
}