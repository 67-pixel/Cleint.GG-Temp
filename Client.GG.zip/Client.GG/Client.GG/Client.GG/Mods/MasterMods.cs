﻿using Photon.Pun;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using static StupidTemplate.Menu.mods;

namespace Unititled_Temp_Mdae_by_JJ.Mods
{

    class MasterMods
    {
        public static void SetColorAll(int color)
        {
            if (PhotonNetwork.IsMasterClient)
                Main.SetPlayerColors(NetworkSystem.Instance.AllNetPlayers.ToDictionary(p => p.ActorNumber, p => color));
            else
                NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> You are not master client.");
        }
        private static float playerColorDelay;
        public static void SetColorSelf(int color) =>
            Main.SetPlayerColors(new Dictionary<int, int> { { NetworkSystem.Instance.LocalPlayer.ActorNumber, color } });

    }
}

class ColorGun
{
    public static void SetColorAllGun(int color)
    {
        GunTemplate.StartBothGuns(delegate
        {
            if (PhotonNetwork.IsMasterClient)
            {
                Main.SetPlayerColors(NetworkSystem.Instance.AllNetPlayers
                    .ToDictionary(p => p.ActorNumber, p => color));
            }
            else
            {
                Debug.LogError("<color=red>ERROR! NOT MASTER CLIENT</color>");
            }
        }, true);
    }

}

