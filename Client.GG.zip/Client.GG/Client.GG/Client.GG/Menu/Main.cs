﻿using BepInEx;
using GorillaLocomotion;
using HarmonyLib;
using keysys;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Notifications;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Networking;
using UnityEngine.UI;
using static AetherTemp.Menu.Buttons;
using static StupidTemplate.Settings;

namespace StupidTemplate.Menu
{
    [HarmonyPatch(typeof(GorillaLocomotion.GTPlayer))]
    [HarmonyPatch("LateUpdate", MethodType.Normal)]
    public class Main : MonoBehaviour
    {

        public static float num = 2f;

        public static void MenuDeleteTime()
        {
            if (num == 2f)
                num = 5f; // Long
            else if (num == 5f)
                num = 0.01f; // Fast
            else
                num = 2f; // Default
        }

        // Constant
        public static void Prefix()
        {
            // Initialize Menu
            if (KeySystem.key)
            {
                try
                {
                    bool toOpen = (!rightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton) || (rightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton);
                    bool keyboardOpen = UnityInput.Current.GetKey(keyboardButton);

                    if (menu == null)
                    {
                        if (toOpen || keyboardOpen)
                        {
                            CreateMenu();
                            RecenterMenu(rightHanded, keyboardOpen);
                            GorillaTagger.Instance.StartCoroutine(OpenAni());
                            if (Ani4)
                            {
                                GorillaTagger.Instance.StartCoroutine(WobbleOpenAni());
                            }

                            if (reference == null)
                            {
                                CreateReference(rightHanded);
                            }
                        }
                    }
                    else
                    {
                        if ((toOpen || keyboardOpen))
                        {
                            RecenterMenu(rightHanded, keyboardOpen);
                        }
                        else
                        {
                            GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(true);

                            GorillaTagger.Instance.StartCoroutine(CloseAni());
                            if (Ani4)
                            {
                                GorillaTagger.Instance.StartCoroutine(WobbleCloseAni());
                            }
                        }
                    }
                }
                catch (Exception exc)
                {
                    UnityEngine.Debug.LogError(string.Format("{0} // Error initializing at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
                }

                // Constant
                try
                {
                    // Pre-Execution
                    if (fpsObject != null)
                    {
                        fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                    }

                    // Execute Enabled mods
                    foreach (ButtonInfo[] buttonlist in buttons)
                    {
                        foreach (ButtonInfo v in buttonlist)
                        {
                            if (v.enabled)
                            {
                                if (v.method != null)
                                {
                                    try
                                    {
                                        v.method.Invoke();
                                    }
                                    catch (Exception exc)
                                    {
                                        UnityEngine.Debug.LogError(string.Format("{0} // Error with mod {1} at {2}: {3}", PluginInfo.Name, v.buttonText, exc.StackTrace, exc.Message));
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception exc)
                {
                    UnityEngine.Debug.LogError(string.Format("{0} // Error with executing mods at {1}: {2}", PluginInfo.Name, exc.StackTrace, exc.Message));
                }
            }
        }

        public static void EditArmLength()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f || Mouse.current.rightButton.isPressed)
            {
                armlength += 0.05f;
            }
            if (ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f || Mouse.current.leftButton.isPressed)
            {
                armlength -= 0.05f;
            }
            if (ControllerInputPoller.instance.rightControllerPrimaryButton || Mouse.current.middleButton.isPressed)
            {
                armlength = 1f;
            }
            GTPlayer.Instance.transform.localScale = new Vector3(armlength, armlength, armlength);
        }

        public static void ColorLib2(Color color, object target = null)
        {
            PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
            PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
            PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));



            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PlayerPrefs.Save();

            try
            {
                if (target == null)
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", RpcTarget.All, new object[] { color.r, color.g, color.b });
                else
                {
                    if (target is NetPlayer player)
                        GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", player, new object[] { color.r, color.g, color.b });
                    else if (target is RpcTarget targets)
                        GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", targets, new object[] { color.r, color.g, color.b });
                }


            }
            catch { }
        }
        public static void SetPlayerColors(Dictionary<int, int> colors) // ActorNumber : Team // 0 = Blue, 1 = Red, -1 = None
        {
            var filteredPlayers = NetworkSystem.Instance.AllNetPlayers
                .Where(p => colors.ContainsKey(p.ActorNumber));
            MonkeBallGame.Instance.photonView.RPC(
                "RequestSetGameStateRPC",
                RpcTarget.All,
                (int)MonkeBallGame.GameState.Playing,
                PhotonNetwork.Time + (MonkeBallGame.Instance.gameDuration - 1f),
                filteredPlayers.Select(p => p.ActorNumber).ToArray(),
                filteredPlayers.Select(p => colors[p.ActorNumber]).ToArray(),
                new int[MonkeBallGame.Instance.team.Count],
                MonkeBallGame.Instance.startingBalls
                    .Select(ball => BitPackUtils.PackHandPosRotForNetwork(ball.transform.position, ball.transform.rotation))
                    .ToArray(),
                MonkeBallGame.Instance.startingBalls
                    .Select(ball => BitPackUtils.PackWorldPosForNetwork(ball.gameBall.GetVelocity()))
                    .ToArray()
            );
        }
        public static IEnumerator OpenAni()
        {
            if (menu == null) yield break;


            GorillaTagger.Instance.StartCoroutine(PlaySFX(openSfxUrl));


            float duration = 0.45f;
            float elapsed = 0f;
            Vector3 startScale = Vector3.zero;
            Vector3 targetScale = new Vector3(0.1f, 0.3f, 0.3825f);


            while (elapsed < duration)
            {
                if (menu == null) yield break;
                float t = elapsed / duration;

                float s = 1.70158f;
                t -= 1f;
                float bounce = (t * t * ((s + 1f) * t + s) + 1f);
                menu.transform.localScale = Vector3.LerpUnclamped(startScale, targetScale, bounce);
                elapsed += Time.deltaTime;
                yield return null;
            }

            if (menu != null)
                menu.transform.localScale = targetScale;
        }
        public static IEnumerator WobbleOpenAni()
        {
            if (menu == null) yield break;
            GorillaTagger.Instance.StartCoroutine(PlaySFX(openSfxUrl));
            float duration = 0.8f;
            float elapsed = 0f;
            Vector3 startScale = Vector3.zero;
            Vector3 targetScale = new Vector3(0.1f, 0.3f, 0.3825f);
            Vector3 originalPosition = menu.transform.localPosition;

            while (elapsed < duration)
            {
                if (menu == null) yield break;
                float t = elapsed / duration;

                // Overshoot easing
                float c1 = 1.70158f;
                float c3 = c1 + 1f;
                float overshoot = 1f + c3 * Mathf.Pow(t - 1f, 3f) + c1 * Mathf.Pow(t - 1f, 2f);

                // Wobble effect
                float wobbleX = Mathf.Sin(t * Mathf.PI * 6f) * (1f - t) * 0.02f;
                float wobbleY = Mathf.Cos(t * Mathf.PI * 8f) * (1f - t) * 0.01f;

                menu.transform.localScale = Vector3.LerpUnclamped(startScale, targetScale, overshoot);
                menu.transform.localPosition = originalPosition + new Vector3(wobbleX, wobbleY, 0);

                elapsed += Time.deltaTime;
                yield return null;
            }
            if (menu != null)
            {
                menu.transform.localScale = targetScale;
                menu.transform.localPosition = originalPosition;
            }
        }

        public static IEnumerator WobbleCloseAni()
        {
            if (menu == null || Close) yield break;
            Close = true;
            GorillaTagger.Instance.StartCoroutine(PlaySFX(closeSfxUrl));
            float duration = 0.5f;
            float elapsed = 0f;
            Vector3 startScale = menu.transform.localScale;
            Vector3 targetScale = Vector3.zero;
            Vector3 originalPosition = menu.transform.localPosition;

            while (elapsed < duration)
            {
                if (menu == null) yield break;
                float t = elapsed / duration;

                // Ease out back
                float c1 = 1.70158f;
                float c3 = c1 + 1f;
                float easeOut = 1f + c3 * Mathf.Pow(t - 1f, 3f) + c1 * Mathf.Pow(t - 1f, 2f);

                // Shrink wobble
                float wobble = Mathf.Sin(t * Mathf.PI * 4f) * t * 0.015f;

                menu.transform.localScale = Vector3.LerpUnclamped(startScale, targetScale, easeOut);
                menu.transform.localPosition = originalPosition + Vector3.up * wobble;

                elapsed += Time.deltaTime;
                yield return null;
            }
            if (menu != null)
                UnityEngine.Object.Destroy(menu);
            menu = null;
            if (reference != null)
                UnityEngine.Object.Destroy(reference);
            reference = null;
            Close = false;
        }
        public static IEnumerator ElasticOpenAni()
        {
            if (menu == null) yield break;
            GorillaTagger.Instance.StartCoroutine(PlaySFX(openSfxUrl));
            float duration = 0.6f;
            float elapsed = 0f;
            Vector3 startScale = Vector3.zero;
            Vector3 targetScale = new Vector3(0.1f, 0.3f, 0.3825f);
            Quaternion startRotation = menu.transform.localRotation;
            Quaternion targetRotation = startRotation * Quaternion.Euler(0, 360f, 0);

            while (elapsed < duration)
            {
                if (menu == null) yield break;
                float t = elapsed / duration;

                // Elastic easing function
                float c4 = (2f * Mathf.PI) / 3f;
                float elastic = t == 0 ? 0 : t == 1 ? 1 :
                    Mathf.Pow(2f, -10f * t) * Mathf.Sin((t * 10f - 0.75f) * c4) + 1f;

                menu.transform.localScale = Vector3.LerpUnclamped(startScale, targetScale, elastic);
                menu.transform.localRotation = Quaternion.LerpUnclamped(startRotation, targetRotation, t * t);

                elapsed += Time.deltaTime;
                yield return null;
            }
            if (menu != null)
            {
                menu.transform.localScale = targetScale;
                menu.transform.localRotation = startRotation;
            }
        }


        public static IEnumerator ElasticCloseAni()
        {
            if (menu == null || Close) yield break;
            Close = true;
            GorillaTagger.Instance.StartCoroutine(PlaySFX(closeSfxUrl));
            float duration = 0.4f;
            float elapsed = 0f;
            Vector3 startScale = menu.transform.localScale;
            Vector3 targetScale = Vector3.zero;
            Quaternion startRotation = menu.transform.localRotation;
            Quaternion targetRotation = startRotation * Quaternion.Euler(0, -180f, 0);

            while (elapsed < duration)
            {
                if (menu == null) yield break;
                float t = elapsed / duration;

                // Ease in cubic
                float cubic = t * t * t;

                menu.transform.localScale = Vector3.LerpUnclamped(startScale, targetScale, cubic);
                menu.transform.localRotation = Quaternion.LerpUnclamped(startRotation, targetRotation, t);

                elapsed += Time.deltaTime;
                yield return null;
            }
            if (menu != null)
                UnityEngine.Object.Destroy(menu);
            menu = null;
            if (reference != null)
                UnityEngine.Object.Destroy(reference);
            reference = null;
            Close = false;
        }
        public static IEnumerator PlaySFX(string url)
        {
            using (UnityWebRequest www = UnityWebRequestMultimedia.GetAudioClip(url, AudioType.MPEG))
            {
                yield return www.SendWebRequest();

                if (www.result == UnityWebRequest.Result.ConnectionError ||
                    www.result == UnityWebRequest.Result.ProtocolError)
                {
                    Debug.LogError("Audio download error: " + www.error);
                }
                else
                {
                    AudioClip clip = DownloadHandlerAudioClip.GetContent(www);
                    GameObject go = new GameObject("felsound");
                    AudioSource source = go.AddComponent<AudioSource>();
                    source.clip = clip;
                    source.Play();
                    UnityEngine.Object.Destroy(go, clip.length);
                }
            }
        }


        public static IEnumerator CloseAni()
        {
            if (menu == null || Close) yield break;

            Close = true;

            GorillaTagger.Instance.StartCoroutine(PlaySFX(closeSfxUrl));

            float duration = 0.35f;
            float elapsed = 0f;
            Vector3 startScale = menu.transform.localScale;
            Vector3 targetScale = Vector3.zero;


            while (elapsed < duration)
            {
                if (menu == null) yield break;
                float t = elapsed / duration;

                float s = 1.70158f;
                float bounce = t * t * ((s + 1f) * t - s);
                menu.transform.localScale = Vector3.LerpUnclamped(startScale, targetScale, bounce);
                elapsed += Time.deltaTime;
                yield return null;
            }

            if (menu != null)
                UnityEngine.Object.Destroy(menu);
            menu = null;

            if (reference != null)
                UnityEngine.Object.Destroy(reference);
            reference = null;

            Close = false;
        }

        private static IEnumerator AnimateTitle(Text text)
        {
            string targetText = PluginInfo.Name;
            string currentText = "";

            while (true)
            {
                for (int i = 0; i <= targetText.Length; i++)
                {
                    currentText = targetText.Substring(0, i);
                    text.text = currentText;
                    yield return new WaitForSeconds(0.25f);
                }
                yield return new WaitForSeconds(0.5f);
                text.text = "";
                yield return new WaitForSeconds(0.25f);
            }
        }




        public static bool Close = false;

        // Functions
        public static void CreateMenu()
        {
            // Menu Holder
            menu = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menu.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menu.GetComponent<BoxCollider>());
            UnityEngine.Object.Destroy(menu.GetComponent<Renderer>());
            menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);

            // Menu Background
            menuBackground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuBackground.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuBackground.GetComponent<BoxCollider>());
            menuBackground.transform.parent = menu.transform;
            menuBackground.transform.rotation = Quaternion.identity;
            menuBackground.transform.localScale = menuSize;
            menuBackground.GetComponent<Renderer>().material.color = backgroundColor.colors[0].color;
            menuBackground.transform.position = new Vector3(0.05f, 0f, 0f);
            menuBackground.GetComponent<Renderer>().material.color = Color.gray1;

            GameObject menuBackground1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            UnityEngine.Object.Destroy(menuBackground1.GetComponent<Rigidbody>());
            UnityEngine.Object.Destroy(menuBackground1.GetComponent<BoxCollider>());
            menuBackground1.transform.parent = menu.transform;
            menuBackground1.transform.rotation = Quaternion.identity;
            menuBackground1.transform.localScale = menuSize1;
            menuBackground1.transform.position = new Vector3(0.05f, 0f, 0f);

            menuBackground1.GetComponent<Renderer>().material.color = new Color(0f, 0f, 1f, 1f);

            menuBackground1.GetComponent<Renderer>().enabled = false;


            float bevel = 0.02f;

            Renderer ToRoundRenderer = menuBackground1.GetComponent<Renderer>();


            GameObject BaseA = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseA.GetComponent<Collider>());
            BaseA.transform.parent = menu.transform;
            BaseA.transform.rotation = Quaternion.identity;
            BaseA.transform.localPosition = menuBackground1.transform.localPosition;
            BaseA.transform.localScale = menuBackground1.transform.localScale + new Vector3(0f, bevel * -2.55f, 0f);

            GameObject BaseB = GameObject.CreatePrimitive(PrimitiveType.Cube);
            BaseB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(BaseB.GetComponent<Collider>());
            BaseB.transform.parent = menu.transform;
            BaseB.transform.rotation = Quaternion.identity;
            BaseB.transform.localPosition = menuBackground1.transform.localPosition;
            BaseB.transform.localScale = menuBackground1.transform.localScale + new Vector3(0f, 0f, -bevel * 2f);

            GameObject RoundCornerA = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerA.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerA.GetComponent<Collider>());
            RoundCornerA.transform.parent = menu.transform;
            RoundCornerA.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerA.transform.localPosition = menuBackground1.transform.localPosition + new Vector3(0f, (menuBackground1.transform.localScale.y / 2f) - (bevel * 1.275f), (menuBackground1.transform.localScale.z / 2f) - bevel);
            RoundCornerA.transform.localScale = new Vector3(bevel * 2.55f, menuBackground1.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerB = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerB.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerB.GetComponent<Collider>());
            RoundCornerB.transform.parent = menu.transform;
            RoundCornerB.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerB.transform.localPosition = menuBackground1.transform.localPosition + new Vector3(0f, -(menuBackground1.transform.localScale.y / 2f) + (bevel * 1.275f), (menuBackground1.transform.localScale.z / 2f) - bevel);
            RoundCornerB.transform.localScale = new Vector3(bevel * 2.55f, menuBackground1.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerC = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerC.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerC.GetComponent<Collider>());
            RoundCornerC.transform.parent = menu.transform;
            RoundCornerC.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerC.transform.localPosition = menuBackground1.transform.localPosition + new Vector3(0f, (menuBackground1.transform.localScale.y / 2f) - (bevel * 1.275f), -(menuBackground1.transform.localScale.z / 2f) + bevel);
            RoundCornerC.transform.localScale = new Vector3(bevel * 2.55f, menuBackground1.transform.localScale.x / 2f, bevel * 2f);

            GameObject RoundCornerD = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            RoundCornerD.GetComponent<Renderer>().enabled = true;
            UnityEngine.Object.Destroy(RoundCornerD.GetComponent<Collider>());
            RoundCornerD.transform.parent = menu.transform;
            RoundCornerD.transform.rotation = Quaternion.Euler(0f, 0f, 90f);
            RoundCornerD.transform.localPosition = menuBackground1.transform.localPosition + new Vector3(0f, -(menuBackground1.transform.localScale.y / 2f) + (bevel * 1.275f), -(menuBackground1.transform.localScale.z / 2f) + bevel);
            RoundCornerD.transform.localScale = new Vector3(bevel * 2.55f, menuBackground1.transform.localScale.x / 2f, bevel * 2f);

            GameObject[] ToChange = new GameObject[]
            {
    BaseA,
    BaseB,
    RoundCornerA,
    RoundCornerB,
    RoundCornerC,
    RoundCornerD
            };

            foreach (GameObject obj in ToChange)
            {
                obj.GetComponent<Renderer>().material.color = new Color(0f, 0f, 1f, 1f); // pure blue
            }

            // Canvas
            canvasObject = new GameObject();
            canvasObject.transform.parent = menu.transform;
            Canvas canvas = canvasObject.AddComponent<Canvas>();
            CanvasScaler canvasScaler = canvasObject.AddComponent<CanvasScaler>();
            canvasObject.AddComponent<GraphicRaycaster>();
            canvas.renderMode = RenderMode.WorldSpace;
            canvasScaler.dynamicPixelsPerUnit = 1000f;

            // Title and FPS
            Text text = new GameObject
            {
                transform =
        {
            parent = canvasObject.transform
        }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = "<color=blue>Client.gg | V1.0</color>";
            text.fontSize = 1;
            text.color = textColors[0];
            text.supportRichText = true;
            text.fontStyle = FontStyle.Italic;
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.28f, 0.05f);
            component.position = new Vector3(0.06f, 0f, 0.155f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            if (fpsCounter)
            {
                fpsObject = new GameObject
                {
                    transform =
            {
                parent = canvasObject.transform
            }
                }.AddComponent<Text>();
                fpsObject.font = currentFont;
                fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
                fpsObject.color = textColors[0];
                fpsObject.fontSize = 1;
                fpsObject.supportRichText = true;
                fpsObject.fontStyle = FontStyle.Normal;
                fpsObject.alignment = TextAnchor.MiddleCenter;
                fpsObject.horizontalOverflow = UnityEngine.HorizontalWrapMode.Overflow;
                fpsObject.resizeTextForBestFit = true;
                fpsObject.resizeTextMinSize = 0;
                RectTransform component2 = fpsObject.GetComponent<RectTransform>();
                component2.localPosition = Vector3.zero;
                component2.sizeDelta = new Vector2(0.28f, 0.02f);
                component2.position = new Vector3(0.04f, 0f, 0.135f);
                component2.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }


            if (disconnectButton)
            {
                GameObject disconnectbutton = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    disconnectbutton.layer = 2;
                }
                UnityEngine.Object.Destroy(disconnectbutton.GetComponent<Rigidbody>());
                disconnectbutton.GetComponent<BoxCollider>().isTrigger = true;
                disconnectbutton.transform.parent = menu.transform;
                disconnectbutton.transform.rotation = Quaternion.identity;
                disconnectbutton.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
                disconnectbutton.transform.localPosition = new Vector3(0.56f, 0f, 0.56f);
                disconnectbutton.GetComponent<Renderer>().material.color = Color.gray1;
                disconnectbutton.AddComponent<Classes.Button>().relatedText = "Disconnect";
                GameObject gameObjectD = GameObject.CreatePrimitive(PrimitiveType.Cube);
                if (!UnityInput.Current.GetKey(KeyCode.Q))
                {
                    gameObjectD.layer = 2;
                }
                UnityEngine.Object.Destroy(gameObjectD.GetComponent<Rigidbody>());
                gameObjectD.GetComponent<BoxCollider>().isTrigger = true;
                gameObjectD.transform.parent = menu.transform;
                gameObjectD.transform.rotation = Quaternion.identity;
                gameObjectD.transform.localScale = new Vector3(0.11f, 1.0f, 0.10f);
                gameObjectD.transform.localPosition = new Vector3(0.54f, 0f, 0.56f);
                gameObjectD.GetComponent<Renderer>().material.color = new Color(0f, 0f, 1f, 1f); // pure blue

                Text discontext = new GameObject
                {
                    transform =
            {
                parent = canvasObject.transform
            }
                }.AddComponent<Text>();
                discontext.text = "Disconnect";
                discontext.font = currentFont;
                discontext.fontSize = 1;
                discontext.color = textColors[0];
                discontext.alignment = TextAnchor.MiddleCenter;
                discontext.resizeTextForBestFit = true;
                discontext.resizeTextMinSize = 0;

                RectTransform rectt = discontext.GetComponent<RectTransform>();
                rectt.localPosition = Vector3.zero;
                rectt.sizeDelta = new Vector2(0.2f, 0.03f);
                rectt.localPosition = new Vector3(0.064f, 0f, 0.215f);
                rectt.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
            }


            GameObject Home = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                Home.layer = 2;
            }
            UnityEngine.Object.Destroy(Home.GetComponent<Rigidbody>());
            Home.GetComponent<BoxCollider>().isTrigger = true;
            Home.transform.parent = menu.transform;
            Home.transform.rotation = Quaternion.identity;
            Home.transform.localScale = new Vector3(0.1f, 0.5f, 0.1f);
            Home.transform.localPosition = new Vector3(0.56f, 0f, -0.6f);
            Home.GetComponent<Renderer>().material.color = Color.gray1;
            Home.AddComponent<Classes.Button>().relatedText = "home";

            GameObject gameObject1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject1.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject1.GetComponent<Rigidbody>());
            gameObject1.GetComponent<BoxCollider>().isTrigger = true;
            gameObject1.transform.parent = menu.transform;
            gameObject1.transform.rotation = Quaternion.identity;
            gameObject1.transform.localScale = new Vector3(0.095f, 0.52f, 0.11f);
            gameObject1.transform.localPosition = new Vector3(0.56f, 0f, -0.6f);
            gameObject1.GetComponent<Renderer>().material.color = new Color(0f, 0f, 1f, 1f); // pure blue


            Text Homentext = new GameObject
            {
                transform =
            {
                parent = canvasObject.transform
            }
            }.AddComponent<Text>();
            Homentext.text = "\u2302";
            Homentext.font = currentFont;
            Homentext.fontSize = 15;
            Homentext.color = textColors[0];
            Homentext.alignment = TextAnchor.MiddleCenter;
            Homentext.resizeTextForBestFit = true;
            Homentext.resizeTextMinSize = 0;

            RectTransform rectt1 = Homentext.GetComponent<RectTransform>();
            rectt1.localPosition = Vector3.zero;
            rectt1.sizeDelta = new Vector2(0.2f, 0.02f);
            rectt1.localPosition = new Vector3(0.062f, 0f, -0.23f);
            rectt1.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.06f, 0.4f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0.3f, -0.4f);
            gameObject.GetComponent<Renderer>().material.color = Color.gray2;
            gameObject.AddComponent<Classes.Button>().relatedText = "PreviousPage";


            text = new GameObject
            {
                transform =
        {
            parent = canvasObject.transform
        }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = "<";
            text.fontSize = 1;
            text.color = textColors[0];
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.06f, 0.09f, -0.155f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.06f, 0.4f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, -0.3f, -0.4f);
            gameObject.GetComponent<Renderer>().material.color = Color.gray2;
            gameObject.AddComponent<Classes.Button>().relatedText = "NextPage";



            text = new GameObject
            {
                transform =
        {
            parent = canvasObject.transform
        }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = ">";
            text.fontSize = 1;
            text.color = textColors[0];
            text.alignment = TextAnchor.MiddleCenter;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(0.2f, 0.03f);
            component.localPosition = new Vector3(0.06f, -0.09f, -0.155f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));

            // Mod Buttons
            ButtonInfo[] activeButtons = buttons[buttonsType].Skip(pageNumber * buttonsPerPage).Take(buttonsPerPage).ToArray();
            for (int i = 0; i < activeButtons.Length; i++)
            {
                CreateButton(i * 0.092F, activeButtons[i]);
            }
        }






        public static void CreateButton(float offset, ButtonInfo method)
        {

            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            if (!UnityInput.Current.GetKey(KeyCode.Q))
            {
                gameObject.layer = 2;
            }
            UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
            gameObject.GetComponent<BoxCollider>().isTrigger = true;
            gameObject.transform.parent = menu.transform;
            gameObject.transform.rotation = Quaternion.identity;
            gameObject.transform.localScale = new Vector3(0.06f, 1f, 0.08f);
            gameObject.transform.localPosition = new Vector3(0.56f, 0f, 0.27f - offset);
            gameObject.AddComponent<Classes.Button>().relatedText = method.buttonText;
            gameObject.GetComponent<Renderer>().material.color = Color.gray2;

            ColorChanger colorChanger = gameObject.AddComponent<ColorChanger>();
            if (method.enabled)
            {
                colorChanger.colorInfo = buttonColors[1];
            }
            else
            {
                colorChanger.colorInfo = buttonColors[0];
            }
            colorChanger.Start();

            Text text = new GameObject
            {
                transform =
                {
                    parent = canvasObject.transform
                }
            }.AddComponent<Text>();
            text.font = currentFont;
            text.text = method.buttonText;
            if (method.overlapText != null)
            {
                text.text = method.overlapText;
            }
            text.supportRichText = true;
            text.fontSize = 1;
            if (method.enabled)
            {
                text.color = textColors[1];
            }
            else
            {
                text.color = textColors[0];
            }
            text.alignment = TextAnchor.MiddleCenter;
            text.fontStyle = FontStyle.Normal;
            text.resizeTextForBestFit = true;
            text.resizeTextMinSize = 0;
            RectTransform component = text.GetComponent<RectTransform>();
            component.localPosition = Vector3.zero;
            component.sizeDelta = new Vector2(.2f, .03f);
            component.localPosition = new Vector3(.0595f, 0, 0.104f - offset / 2.6f);
            component.rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
        }



        public static void RecreateMenu()
        {
            if (menu != null)
            {
                UnityEngine.Object.Destroy(menu);
                menu = null;

                CreateMenu();
                RecenterMenu(rightHanded, UnityInput.Current.GetKey(keyboardButton));
            }
        }

        public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
        {
            if (!isKeyboardCondition)
            {
                if (!isRightHanded)
                {
                    menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
                    menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
                }
                else
                {
                    menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
                    Vector3 rotation = GorillaTagger.Instance.rightHandTransform.rotation.eulerAngles;
                    rotation += new Vector3(0f, 0f, 180f);
                    menu.transform.rotation = Quaternion.Euler(rotation);
                }
            }
            else
            {
                try
                {
                    TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
                }
                catch { }

                GameObject.Find("Shoulder Camera").transform.Find("CM vcam1").gameObject.SetActive(false);

                if (TPC != null)
                {
                    TPC.transform.position = new Vector3(-999f, -999f, -999f);
                    TPC.transform.rotation = Quaternion.identity;
                    GameObject bg = GameObject.CreatePrimitive(PrimitiveType.Cube);
                    bg.transform.localScale = new Vector3(10f, 10f, 0.01f);
                    bg.transform.transform.position = TPC.transform.position + TPC.transform.forward;
                    bg.GetComponent<Renderer>().material.color = new Color32((byte)(backgroundColor.colors[0].color.r * 50), (byte)(backgroundColor.colors[0].color.g * 50), (byte)(backgroundColor.colors[0].color.b * 50), 255);
                    GameObject.Destroy(bg, Time.deltaTime);
                    menu.transform.parent = TPC.transform;
                    menu.transform.position = (TPC.transform.position + (Vector3.Scale(TPC.transform.forward, new Vector3(0.5f, 0.5f, 0.5f)))) + (Vector3.Scale(TPC.transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
                    Vector3 rot = TPC.transform.rotation.eulerAngles;
                    rot = new Vector3(rot.x - 90, rot.y + 90, rot.z);
                    menu.transform.rotation = Quaternion.Euler(rot);

                    if (reference != null)
                    {
                        if (Mouse.current.leftButton.isPressed)
                        {
                            Ray ray = TPC.ScreenPointToRay(Mouse.current.position.ReadValue());
                            RaycastHit hit;
                            bool worked = Physics.Raycast(ray, out hit, 100);
                            if (worked)
                            {
                                Classes.Button collide = hit.transform.gameObject.GetComponent<Classes.Button>();
                                if (collide != null)
                                {
                                    collide.OnTriggerEnter(buttonCollider);
                                }
                            }
                        }
                        else
                        {
                            reference.transform.position = new Vector3(999f, -999f, -999f);
                        }
                    }
                }
            }
        }

        public static void CreateReference(bool isRightHanded)
        {
            reference = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            if (isRightHanded)
            {
                reference.transform.parent = GorillaTagger.Instance.leftHandTransform;
            }
            else
            {
                reference.transform.parent = GorillaTagger.Instance.rightHandTransform;
            }
            reference.GetComponent<Renderer>().material.color = backgroundColor.colors[0].color;
            reference.transform.localPosition = new Vector3(0f, -0.1f, 0f);
            reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
            buttonCollider = reference.GetComponent<SphereCollider>();

            ColorChanger colorChanger = reference.AddComponent<ColorChanger>();
            colorChanger.colorInfo = backgroundColor;
            colorChanger.Start();
        }

        public static void Toggle(string buttonText, bool fromMenu = false, bool ignoreForce = false)
        {
            int lastPage = ((buttons[buttonsType].Length + buttonsPerPage - 1) / buttonsPerPage) - 1;
            if (buttonText == "PreviousPage")
            {
                pageNumber--;
                if (pageNumber < 0)
                {
                    pageNumber = lastPage;
                }
            }
            else
            {
                if (buttonText == "NextPage")
                {
                    pageNumber++;
                    if (pageNumber > lastPage)
                    {
                        pageNumber = 0;
                    }
                }
                else
                {
                    ButtonInfo target = GetIndex(buttonText);
                    if (target != null)
                    {
                        if (target.isTogglable)
                        {
                            target.enabled = !target.enabled;
                            if (target.enabled)
                            {
                                NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + target.toolTip);
                                if (target.enableMethod != null)
                                {
                                    try { target.enableMethod.Invoke(); } catch { }
                                }
                            }
                            else
                            {
                                NotifiLib.SendNotification("<color=grey>[</color><color=red>DISABLE</color><color=grey>]</color> " + target.toolTip);
                                if (target.disableMethod != null)
                                {
                                    try { target.disableMethod.Invoke(); } catch { }
                                }
                            }
                        }
                        else
                        {
                            NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + target.toolTip);
                            if (target.method != null)
                            {
                                try { target.method.Invoke(); } catch { }
                            }
                        }
                    }
                    else
                    {
                        UnityEngine.Debug.LogError(buttonText + " does not exist");
                    }
                }
            }
            RecreateMenu();
        }

        public static GradientColorKey[] GetSolidGradient(Color color)
        {
            return new GradientColorKey[] { new GradientColorKey(color, 0f), new GradientColorKey(color, 1f) };
        }

        public static ButtonInfo GetIndex(string buttonText)
        {
            foreach (ButtonInfo[] buttons in buttons)
            {
                foreach (ButtonInfo button in buttons)
                {
                    if (button.buttonText == buttonText)
                    {
                        return button;
                    }
                }
            }

            return null;
        }

        // Variables
        // Important
        // Objects
        public static GameObject menu;
        public static GameObject menuBackground;
        public static GameObject reference;
        public static GameObject canvasObject;

        public static SphereCollider buttonCollider;
        public static Camera TPC;
        public static Text fpsObject;

        // Data
        public static int pageNumber = 0;
        public static int buttonsType = 0;
        public static string openSfxUrl = "https://github.com/okcauq/menusounds/raw/refs/heads/main/ui-appear-101soundboards.mp3";
        public static string closeSfxUrl = "https://github.com/okcauq/menusounds/raw/refs/heads/main/ui-disappear-101soundboards.mp3";
        public static string buttonSfxUrl = "https://github.com/okcauq/menusounds/raw/refs/heads/main/sound.mp3";
        public static bool Ani4;
        public static float subThingyZ;
        public static float startX;
        public static float startY;
        public static float flySpeed = 10f;
        public static bool hasRemovedThisFrame;
        public static bool NoOverlapRPCs = true;
        public static float subThingy;
        public static Material bgMat = new Material(Shader.Find("GorillaTag/UberShader"));
        public static Material ForestMat = null;
        public static Material StumpMat = null;
        public static string StumpLeaderboardID = "UnityTempFile";
        public static string ForestLeaderboardID = "UnityTempFile";
        public static int StumpLeaderboardIndex = 5;
        public static int ForestLeaderboardIndex = 9;
        public static bool boardshit = true;
        public static VRRig GhostRig;
        public static float armlength = 1f;
        public static FontStyle activeFontStyle;
        private static readonly Dictionary<VRRig, GameObject> creationDateTags = new Dictionary<VRRig, GameObject>();


    }
}
