﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using BepInEx;
using System.Collections;
using UnityEngine.InputSystem;
using UnityEngine.XR;

namespace TwoTimeDarkUnititledTempmadebyme.Menu
{

    public class Gun2 : MonoBehaviour
    {
        public static int LineCurve = 200;
        private const float PointerScale = 0.2f;
        private const float LineWidth = 0.035f;
        private const float LineSmoothFactor = 8f;
        private const float DestroyDelay = 0.02f;
        private const float PulseSpeed = 3f;
        private const float PulseAmplitude = 0.15f;
        private const float GlowIntensity = 1.5f;

        public static GameObject spherepointer;
        public static VRRig LockedPlayer;
        public static Vector3 lr;

        public static Color32 PointerColor = Color.softRed;
        public static Color32 LineColor = new Color32(138, 43, 226, 200);
        public static Color32 TriggeredPointerColor = new Color32(255, 0, 128, 255);
        public static Color32 TriggeredLineColor = new Color32(255, 20, 147, 255);
        public static Color32 CoreLineColor = new Color32(255, 255, 255, 255);


        private static Vector3 CalculateBezierPoint(Vector3 start, Vector3 mid, Vector3 end, float t)
        {
            return Mathf.Pow(1 - t, 2) * start + 2 * (1 - t) * t * mid + Mathf.Pow(t, 2) * end;
        }

        private static void CurveLineRenderer(LineRenderer lineRenderer, Vector3 start, Vector3 mid, Vector3 end)
        {
            lineRenderer.positionCount = LineCurve;
            Vector3 direction = (end - start).normalized;
            Vector3 perpendicular1 = Vector3.Cross(direction, Vector3.up).normalized;
            if (perpendicular1 == Vector3.zero) perpendicular1 = Vector3.Cross(direction, Vector3.right).normalized;
            Vector3 perpendicular2 = Vector3.Cross(direction, perpendicular1).normalized;

            float spiralRadius = 0.25f;
            float spiralSpeed = 5f;
            float spiralFrequency = 3f;

            for (int i = 0; i < LineCurve; i++)
            {
                float t = (float)i / (LineCurve - 1);
                Vector3 basePoint = CalculateBezierPoint(start, mid, end, t);

                float fadeInOut = Mathf.Sin(t * Mathf.PI);

                float angle = t * Mathf.PI * 2f * spiralFrequency + Time.time * spiralSpeed;
                float radius = spiralRadius * fadeInOut;

                Vector3 offset = (perpendicular1 * Mathf.Cos(angle) + perpendicular2 * Mathf.Sin(angle)) * radius;

                lineRenderer.SetPosition(i, basePoint + offset);
            }
        }

        private static IEnumerator StartCurvyLineRenderer(LineRenderer lineRenderer, Vector3 start, Vector3 mid, Vector3 end)
        {
            while (true)
            {
                CurveLineRenderer(lineRenderer, start, mid, end);

                float pulse = Mathf.PingPong(Time.time * 2f, 1f);
                Color startColor = Color.Lerp(lineRenderer.startColor,
                    new Color(lineRenderer.startColor.r, lineRenderer.startColor.g, lineRenderer.startColor.b, 0.6f + pulse * 0.4f),
                    Time.deltaTime * 3f);

                lineRenderer.startColor = startColor;
                lineRenderer.endColor = new Color(startColor.r, startColor.g, startColor.b, startColor.a * 0.3f);

                yield return null;
            }
        }

        private static IEnumerator PulsePointer(GameObject pointer)
        {
            Vector3 originalScale = pointer.transform.localScale;
            float time = 0f;

            while (true)
            {
                time += Time.deltaTime * PulseSpeed;

                float scaleFactor = 1 + Mathf.Sin(time) * PulseAmplitude;
                pointer.transform.localScale = originalScale * scaleFactor;

                Renderer rend = pointer.GetComponent<Renderer>();
                if (rend != null && LockedPlayer == null)
                {
                    float colorPulse = Mathf.PingPong(time * 0.5f, 1f);
                    Color baseColor = PointerColor;
                    rend.material.color = Color.Lerp(baseColor, Color.white, colorPulse * 0.3f);
                }

                yield return null;
            }
        }

        private static GameObject CreateEnhancedPointer()
        {
            GameObject pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            pointer.AddComponent<Renderer>();
            pointer.transform.localScale = new Vector3(0.12f, 0.12f, 0.12f);

            Material mat = new Material(Shader.Find("GUI/Text Shader"));
            mat.color = PointerColor;
            pointer.GetComponent<Renderer>().material = mat;

            Destroy(pointer.GetComponent<BoxCollider>());
            Destroy(pointer.GetComponent<Rigidbody>());
            Destroy(pointer.GetComponent<Collider>());

            GameObject innerGlow = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            innerGlow.transform.SetParent(pointer.transform);
            innerGlow.transform.localPosition = Vector3.zero;
            innerGlow.transform.localScale = Vector3.one * 1.5f;
            Material glowMat = new Material(Shader.Find("GUI/Text Shader"));
            glowMat.color = new Color(PointerColor.r / 255f, PointerColor.g / 255f, PointerColor.b / 255f, 0.3f);
            innerGlow.GetComponent<Renderer>().material = glowMat;
            Destroy(innerGlow.GetComponent<Collider>());

            return pointer;
        }

        private static LineRenderer CreateEnhancedLine(GameObject parent, bool isCore = false)
        {
            LineRenderer lineRenderer = parent.AddComponent<LineRenderer>();

            if (isCore)
            {
                lineRenderer.startWidth = LineWidth * 0.4f;
                lineRenderer.endWidth = LineWidth * 0.4f;
                lineRenderer.startColor = CoreLineColor;
                lineRenderer.endColor = new Color(CoreLineColor.r / 255f, CoreLineColor.g / 255f, CoreLineColor.b / 255f, 0.5f);
            }
            else
            {
                lineRenderer.startWidth = LineWidth;
                lineRenderer.endWidth = LineWidth;
                lineRenderer.startColor = LineColor;
                lineRenderer.endColor = new Color(LineColor.r / 255f, LineColor.g / 255f, LineColor.b / 255f, 0.2f);
            }

            lineRenderer.useWorldSpace = true;
            lineRenderer.material = new Material(Shader.Find("GUI/Text Shader"));
            lineRenderer.numCapVertices = 5;

            return lineRenderer;
        }

        public static RaycastHit raycastHit;
        public static bool trigger = false;

        public static void StartVrGun(Action action, bool LockOn)
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, -GorillaTagger.Instance.rightHandTransform.up, out raycastHit, float.MaxValue);

                if (spherepointer == null)
                {
                    spherepointer = CreateEnhancedPointer();
                    lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
                    spherepointer.AddComponent<Gun2>().StartCoroutine(PulsePointer(spherepointer));
                }

                if (LockedPlayer == null)
                {
                    spherepointer.transform.position = raycastHit.point;
                    spherepointer.GetComponent<Renderer>().material.color = PointerColor;
                }
                else
                {
                    spherepointer.transform.position = LockedPlayer.transform.position;
                }

                lr = Vector3.Lerp(lr, (GorillaTagger.Instance.rightHandTransform.position + spherepointer.transform.position) / 2f, Time.deltaTime * LineSmoothFactor);

                GameObject outerLine = new GameObject("OuterLine");
                LineRenderer outerRenderer = CreateEnhancedLine(outerLine, false);
                outerLine.AddComponent<Gun2>().StartCoroutine(StartCurvyLineRenderer(outerRenderer, GorillaTagger.Instance.rightHandTransform.position, lr, spherepointer.transform.position));

                GameObject coreLine = new GameObject("CoreLine");
                LineRenderer coreRenderer = CreateEnhancedLine(coreLine, true);
                coreLine.AddComponent<Gun2>().StartCoroutine(StartCurvyLineRenderer(coreRenderer, GorillaTagger.Instance.rightHandTransform.position, lr, spherepointer.transform.position));

                Destroy(outerRenderer, Time.deltaTime);
                Destroy(coreRenderer, Time.deltaTime);

                if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f)
                {
                    trigger = true;
                    outerRenderer.startColor = TriggeredLineColor;
                    outerRenderer.endColor = new Color(TriggeredLineColor.r / 255f, TriggeredLineColor.g / 255f, TriggeredLineColor.b / 255f, 0.2f);
                    coreRenderer.startColor = Color.white;
                    spherepointer.GetComponent<Renderer>().material.color = TriggeredPointerColor;

                    if (LockOn)
                    {
                        if (LockedPlayer == null)
                        {
                            LockedPlayer = raycastHit.collider.GetComponentInParent<VRRig>();
                        }
                        if (LockedPlayer != null)
                        {
                            spherepointer.transform.position = LockedPlayer.transform.position;
                            action();
                        }
                        return;
                    }
                    action();
                    return;
                }
                else if (LockedPlayer != null)
                {
                    LockedPlayer = null;
                    return;
                }
            }
            else if (spherepointer != null)
            {
                Destroy(spherepointer);
                spherepointer = null;
                LockedPlayer = null;
            }
        }

        public static void StartPcGun(Action action, bool LockOn)
        {
            Ray ray = GameObject.Find("Shoulder Camera").activeSelf ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition);

            if (Mouse.current.rightButton.isPressed)
            {
                RaycastHit raycastHit;
                if (Physics.Raycast(ray.origin, ray.direction, out raycastHit, float.PositiveInfinity, -32777) && spherepointer == null)
                {
                    if (spherepointer == null)
                    {
                        spherepointer = CreateEnhancedPointer();
                        lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
                        spherepointer.AddComponent<Gun2>().StartCoroutine(PulsePointer(spherepointer));
                    }
                }

                if (LockedPlayer == null)
                {
                    spherepointer.transform.position = raycastHit.point;
                    spherepointer.GetComponent<Renderer>().material.color = PointerColor;
                }
                else
                {
                    spherepointer.transform.position = LockedPlayer.transform.position;
                }

                lr = Vector3.Lerp(lr, (GorillaTagger.Instance.rightHandTransform.position + spherepointer.transform.position) / 2f, Time.deltaTime * LineSmoothFactor);

                GameObject outerLine = new GameObject("OuterLine");
                LineRenderer outerRenderer = CreateEnhancedLine(outerLine, false);
                outerLine.AddComponent<Gun2>().StartCoroutine(StartCurvyLineRenderer(outerRenderer, GorillaTagger.Instance.rightHandTransform.position, lr, spherepointer.transform.position));

                GameObject coreLine = new GameObject("CoreLine");
                LineRenderer coreRenderer = CreateEnhancedLine(coreLine, true);
                coreLine.AddComponent<Gun2>().StartCoroutine(StartCurvyLineRenderer(coreRenderer, GorillaTagger.Instance.rightHandTransform.position, lr, spherepointer.transform.position));

                Destroy(outerRenderer, Time.deltaTime);
                Destroy(coreRenderer, Time.deltaTime);

                if (Mouse.current.leftButton.isPressed)
                {
                    trigger = true;
                    outerRenderer.startColor = TriggeredLineColor;
                    outerRenderer.endColor = new Color(TriggeredLineColor.r / 255f, TriggeredLineColor.g / 255f, TriggeredLineColor.b / 255f, 0.2f);
                    coreRenderer.startColor = Color.white;
                    spherepointer.GetComponent<Renderer>().material.color = TriggeredPointerColor;

                    if (LockOn)
                    {
                        if (LockedPlayer == null)
                        {
                            LockedPlayer = raycastHit.collider.GetComponentInParent<VRRig>();
                        }
                        if (LockedPlayer != null)
                        {
                            spherepointer.transform.position = LockedPlayer.transform.position;
                            action();
                        }
                        return;
                    }
                    action();
                    return;
                }
                else if (LockedPlayer != null)
                {
                    LockedPlayer = null;
                    return;
                }
            }
            else if (spherepointer != null)
            {
                Destroy(spherepointer);
                spherepointer = null;
                LockedPlayer = null;
            }
        }

        public static void StartBothGuns(Action action, bool locko)
        {
            if (XRSettings.isDeviceActive)
            {
                StartVrGun(action, locko);
            }
            if (!XRSettings.isDeviceActive)
            {
                StartPcGun(action, locko);
            }
        }
    }
}
