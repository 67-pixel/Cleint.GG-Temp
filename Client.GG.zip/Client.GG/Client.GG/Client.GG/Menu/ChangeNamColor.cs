﻿using ExitGames.Client.Photon;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Menu;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace TWOTIMEPAID.Mods
{
    internal class ChangeNameColor
    {

        public static void ChangeColor(Color color)
        {
            PlayerPrefs.SetFloat("redValue", Mathf.Clamp(color.r, 0f, 1f));
            PlayerPrefs.SetFloat("greenValue", Mathf.Clamp(color.g, 0f, 1f));
            PlayerPrefs.SetFloat("blueValue", Mathf.Clamp(color.b, 0f, 1f));
            GorillaTagger.Instance.UpdateColor(color.r, color.g, color.b);
            PlayerPrefs.Save();
            try
            {
                GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", 0, new object[]
                {
                    color.r,
                    color.g,
                    color.b
                });
                RCPProtect.RPCProtection();
            }
            catch
            {
            }
        }


        public static void ChangeName(string PlayerName)
        {
            GorillaComputer.instance.currentName = PlayerName;
            PhotonNetwork.LocalPlayer.NickName = PlayerName;
            GorillaComputer.instance.SetLocalNameTagText(PlayerName);
            GorillaComputer.instance.savedName = PlayerName;
            PlayerPrefs.SetString("playerName", PlayerName);
            PlayerPrefs.Save();
            try
            {
                bool flag = GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Contains(PhotonNetwork.LocalPlayer.UserId) || CosmeticWardrobeProximityDetector.IsUserNearWardrobe(PhotonNetwork.LocalPlayer.UserId);
                bool flag2 = flag;
                if (flag2)
                {
                    GorillaTagger.Instance.myVRRig.SendRPC("RPC_InitializeNoobMaterial", 0, new object[]
                    {
                        GorillaTagger.Instance.offlineVRRig.playerColor.r,
                        GorillaTagger.Instance.offlineVRRig.playerColor.g,
                        GorillaTagger.Instance.offlineVRRig.playerColor.b
                    });
                    RCPProtect.RPCProtection();
                }
            }
            catch
            {
            }
        }
    }
}

internal class RCPProtect
{

    public static void RPCProtection()
    {
        try
        {
            bool flag = !Main.hasRemovedThisFrame;
            bool flag2 = flag;
            if (flag2)
            {
                bool noOverlapRPCs = Main.NoOverlapRPCs;
                bool flag3 = noOverlapRPCs;
                if (flag3)
                {
                    Main.hasRemovedThisFrame = true;
                }
                bool enabled = Main.GetIndex("Experimental RPC Protection").enabled;
                bool flag4 = enabled;
                if (flag4)
                {
                    PhotonNetwork.RaiseEvent(0, null, new RaiseEventOptions
                    {
                        CachingOption = 0,
                        TargetActors = new int[]
                        {
                            PhotonNetwork.LocalPlayer.ActorNumber
                        }
                    }, SendOptions.SendReliable);
                }
                else
                {
                    GorillaNot.instance.rpcErrorMax = int.MaxValue;
                    GorillaNot.instance.rpcCallLimit = int.MaxValue;
                    GorillaNot.instance.logErrorMax = int.MaxValue;
                    PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
                    PhotonNetwork.QuickResends = int.MaxValue;
                    PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
                    PhotonNetwork.SendAllOutgoingCommands();
                    GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
                }
            }
        }
        catch
        {
            Debug.Log("RPC protection failed, are you in a lobby?");
        }
    }
}